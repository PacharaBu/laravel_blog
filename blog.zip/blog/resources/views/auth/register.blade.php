<?php
	if(auth()->guard()->guest() or Auth::user()->employees['jobTitle'] != "President")
	{
		header('Location: http://localhost:8000/project/products');
		exit;
	}
?>
@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Register') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('register') }}">
                        @csrf

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('employeeNumber') }}</label>

                            <div class="col-md-6">
                                <input id="employeeNumber" type="text" class="form-control @error('employeeNumber') is-invalid @enderror" name="employeeNumber" value="{{ old('employeeNumber') }}" required autocomplete="employeeNumber" autofocus>

                                @error('employeeNumber')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Confirm Password') }}</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

						<hr>
						
						<div class="form-group row">
                            <label for="FirstsName" class="col-md-4 col-form-label text-md-right">{{ __('FirstsName') }}</label>

                            <div class="col-md-6">
                                <input id="FirstsName" type="text" class="form-control @error('FirstsName') is-invalid @enderror" name="FirstsName" value="{{ old('FirstsName') }}" required autocomplete="FirstsName">

                                @error('FirstsName')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
						
						<div class="form-group row">
                            <label for="LastName" class="col-md-4 col-form-label text-md-right">{{ __('LastName') }}</label>

                            <div class="col-md-6">
                                <input id="LastName" type="text" class="form-control @error('LastName') is-invalid @enderror" name="LastName" value="{{ old('LastName') }}" required autocomplete="LastName">

                                @error('LastName')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
						
						<div class="form-group row">
                            <label for="Extension" class="col-md-4 col-form-label text-md-right">{{ __('Extension') }}</label>

                            <div class="col-md-6">
                                <input id="Extension" type="text" class="form-control @error('Extension') is-invalid @enderror" name="Extension" value="{{ old('Extension') }}" required autocomplete="Extension">

                                @error('Extension')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
						
						<div class="form-group row">
                            <label for="Email" class="col-md-4 col-form-label text-md-right">{{ __('Email') }}</label>

                            <div class="col-md-6">
                                <input id="Email" type="text" class="form-control @error('Email') is-invalid @enderror" name="Email" value="{{ old('Email') }}" required autocomplete="Email">

                                @error('Email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
						
						<div class="form-group row">
                            <label for="officeCode" class="col-md-4 col-form-label text-md-right">{{ __('officeCode') }}</label>

                            <div class="col-md-6">
                                <input id="officeCode" type="text" class="form-control @error('officeCode') is-invalid @enderror" name="officeCode" value="{{ old('officeCode') }}" required autocomplete="officeCode">

                                @error('officeCode')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
						
						<div class="form-group row">
                            <label for="reportsTo" class="col-md-4 col-form-label text-md-right">{{ __('reportsTo') }}</label>

                            <div class="col-md-6">
                                <input id="reportsTo" type="text" class="form-control @error('reportsTo') is-invalid @enderror" name="reportsTo" value="{{ old('reportsTo') }}" required autocomplete="reportsTo">

                                @error('reportsTo')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
						
						<div class="form-group row">
                            <label for="jobTitle" class="col-md-4 col-form-label text-md-right">{{ __('jobTitle') }}</label>

                            <div class="col-md-6">
                                <input id="jobTitle" type="text" class="form-control @error('jobTitle') is-invalid @enderror" name="jobTitle" value="{{ old('jobTitle') }}" required autocomplete="jobTitle">

                                @error('jobTitle')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
						
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Register') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
