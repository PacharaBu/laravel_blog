<?php
	if(auth()->guard()->guest())
	{
		header('Location: http://localhost:8000/login');
		exit;
	}
?>
<html>
    <head>
        <title>HOLLOW</title>
		<link rel="shortcut icon" type="image/png" href="http://localhost/laravel/blog/resources/views/image/hollow_icon.png"/>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="http://localhost/laravel/blog/resources/views/css/main.css"> <!--import css file-->
    </head>
    <body class="bg-image-hollow">
	<div class="row" style="margin:0px">
	    <div class="column-left"><img src="http://localhost/laravel/blog/resources/views/image/logo_hollow.png" class="login-logo-image"></div>
        <div class="column-center"><h3>ฉันกำลังจะตาย...จริงๆอยากให้กายตายมันควรจะจบเสียที....แต่ตอนนี้ที่จะตายมันก็แค่ใจฉัน.....ช่างมันถึงกายมันจะไม่สิ้นสุดวันนี้แต่วันนึง....คงจบ</h3></div>
		<div class="column-right"></div>
	</div>
        <ul class="ul-menu-bar">
		@guest
			
		@else
			<li class="li-menu-bar"><a href="http://localhost:8000/hollow/products">products</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/hollow/customers">customers</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/hollow/employees">employees</a></li>
		@endguest
		</ul>
		<div class="row" style="margin:0px">
			<table class="table" style="background-image: url('http://localhost/laravel/blog/resources/views/image/bg_table_hollow.png')">
            <tr>
				<?php  
					foreach($colum as $c)
					{
							echo "<th>";
							echo $c;
							echo "</th>";
                    }
				?>
            </tr>
				<?php
					foreach($data as $row)
					{
						echo "<tr>";
						foreach($colum as $c)
						{
							echo "<td> $row[$c] </td>";
						}
						echo "</tr>";
					}
				?>
        </table>
		<div class="container">
			@foreach ($data as $d)
				{{ $d->name }}
			@endforeach
		</div>

		{{ $data->links() }}
		</div>
    </body>
</html>