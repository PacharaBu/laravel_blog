<html>
<head><title></title></head>
<body>
	<h3>Hello</h3><hr>
	<?php 
		echo "test"; 
	?>
</body>
</html>