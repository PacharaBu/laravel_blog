<?php
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/project/{category}/add_comple','database_project_controller@add');

Route::get('/project/{category}/{key}/edit_comple','database_project_controller@edit_data');

Route::get('/', function () {
    return view('welcome');
});

Route::get('/project/employees/demote/{employeeNumber}','database_project_controller@employees_demote');

Route::get('/project/employees/promote/{employeeNumber}','database_project_controller@employees_promote');

Route::post('/project/{category}/add_comple','database_project_controller@add_comple');

Route::post('/project/{category}/{key}/edit_comple','database_project_controller@edit_comple');

Route::post('/project/add_to_cart/','database_project_controller@add_to_cart');

Route::post('/project/delete_form_cart/','database_project_controller@delete_form_cart');

Route::get('/project/add/{category}/{key?}','database_project_controller@add');

Route::get('/project/edit/{category}/{key}','database_project_controller@edit_data');

Route::get('/project/delete/{category}/{key}','database_project_controller@delete_data');

Route::get('/project/login/','database_project_controller@login');

Route::get('/project/orders/{orderNumber}','database_project_controller@orders_details');

Route::get('/project/products/{productCode}','database_project_controller@products_details');

Route::get('/project/employees/{employeeNumber}','database_project_controller@employees_details');

Route::get('/project/customers/{customerNumber}','database_project_controller@customers_details');

Route::get('/project/products/fillter/{colum}/{fillter}','database_project_controller@products_fillter');

Route::resource('/project','database_project_controller');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/hollow/{category}','database_project_controller@hollow');