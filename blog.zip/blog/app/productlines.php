<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class productlines extends Model
{
    public $table = 'productlines';
	public $key = 'productLine';
}
