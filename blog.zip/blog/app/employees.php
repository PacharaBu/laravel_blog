<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class employees extends Model
{
	public $timestamps = false;
	
    public $table = 'employees';
	public $key = 'employeeNumber';
	
	protected $fillable = ['employeeNumber','lastName','firstName','extension','email','officeCode','reportsTo','jobTitle'];
	
	public function offices()
    {
        return $this->hasOne('App\offices','officeCode','officeCode');
    }
}
