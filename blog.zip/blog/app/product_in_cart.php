<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class product_in_cart extends Model
{
	public $timestamps = false;
	
    public $table = 'product_in_cart';
	
	protected $fillable = ['orderNumber','productCode','productName','quantityOrdered','priceEach'];
}
?>
