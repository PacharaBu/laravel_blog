<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\products;
use App\employees;
use App\customers;
use App\orders;
use App\productlines;

use Illuminate\Support\Facades\Validator;

class database_project_controller extends Controller
{
	public function login_ck()
	{
		//return view("login");
		if(auth()->guard()->guest())
		{
			header('Location: http://localhost:8000/login');
			exit;
		}
	}
	
	public function login()
	{
		//return view("login");
	}
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
		if($id=="products")
		{
			$colum = ["productCode","productName","buyPrice","quantityInStock","productVendor"];
			$data = products::paginate(25);
		}
		else if($id=="orders")
		{
			$colum = ["orderNumber","customerNumber","orderDate","comments","status"];
			$data = orders::paginate(20);
		}
		else if($id=="customers")
		{
			$colum = ["customerNumber","customerName","phone","salesRepEmployeeNumber","creditLimit"];
			$data = customers::paginate(25);
		}
		else if($id=="employees")
		{
			$colum = ["employeeNumber","firstName","lastName","officeCode","jobTitle"];
			$data = employees::paginate(25);
		}
		else
		{
			abort(404);
		}
        return view("main",["data"=>$data,"colum"=>$colum,"category"=>$id]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
	
	public function add($category)
	{
		if($category=="products")
		{
			return view('add_product',["category"=>$category]);
		}
		else if($category=="customers")
		{
			return view('add_customer',["category"=>$category]);
		}
		else
		{
			abort(404);
		}
	}
	
	public function edit_data($category,$key)
	{
		if($category=="products")
		{
			$pk = products::where('productCode', '=', $key)->first();
			if($pk==null)
			{
				abort(404);
			}
			
			$old = products::where('productCode', '=', $key)->first();
			
			return view("edit_product",["category"=>$category,"key"=>$key,"old"=>$old]);
		}
		else if($category=="customers")
		{
			$pk = customers::where('customerNumber', '=', $key)->first();
			if($pk==null)
			{
				abort(404);
			}
			
			$old = customers::where('customerNumber', '=', $key)->first();
			
			return view("edit_customer",["category"=>$category,"key"=>$key,"old"=>$old]);
		}
	}

	public function edit_comple(Request $request,$category,$key)
	{
		$this->login_ck();
		if($category=="products")
		{
			$validatedData = Validator::make($request->all(),[
												'productName' => ['required','string'],
												'productLine' => ['required','string','exists:productlines,productline'],
												'productScale' => ['required'],
												'productVendor' => ['required','string'],
												'productDescription' => ['required','string'],
												'quantityInStock' => ['required'],
												'buyPrice' => ['required'],
												'MSRP' => ['required'],
												]);
			if ($validatedData->fails())
			{
				return redirect()->back()->withErrors($validatedData->errors());
			}
			
			products::where('productCode',$key)->update([
				 'productName' => $request->input('productName'),
				 'productLine' => $request->input('productLine'),
				 'productScale' => $request->input('productScale'),
				 'productVendor' => $request->input('productVendor'),
				 'productDescription' => $request->input('productDescription'),
				 'quantityInStock' => $request->input('quantityInStock'),
				 'buyPrice' => $request->input('buyPrice'),
				 'MSRP' => $request->input('MSRP')
				 ]);
				 
			$data = products::where('productCode', '=', $key)->first();
			return view("product_detail",["data"=>$data,"category"=>"products"]);
		}
		else if($category=="customers")
		{
			$validatedData = Validator::make($request->all(),[
												'customerName' => ['required','string'],
												'contactLastName' => ['required','string'],
												'contactFirstName' => ['required','string'],
												'phone' => ['required'],
												'addressLine1' => ['required'],
												'addressLine2' => ['required'],
												'city' => ['required'],
												'state' => ['required'],
												'postalCode' => ['required'],
												'country' => ['required'],
												'salesRepEmployeeNumber' => ['required','exists:employees,employeeNumber','numeric'],
												'creditLimit' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
												]);
			if ($validatedData->fails())
			{
				return redirect()->back()->withErrors($validatedData->errors())->withInput();
			}
			
			customers::where('customerNumber',$key)->update([
				 'customerName' => $request->input('customerName'),
				 'contactLastName' => $request->input('contactLastName'),
				 'contactFirstName' => $request->input('contactFirstName'),
				 'phone' => $request->input('phone'),
				 'addressLine1' => $request->input('addressLine1'),
				 'addressLine2' => $request->input('addressLine2'),
				 'city' => $request->input('city'),
				 'state' => $request->input('state'),
				 'postalCode' => $request->input('postalCode'),
				 'country' => $request->input('country'),
				 'salesRepEmployeeNumber' => $request->input('salesRepEmployeeNumber'),
				 'creditLimit' => $request->input('creditLimit')
				 ]);
				 
				 $data = customers::where('customerNumber', '=', $key)->first();
				 return view("customer_detail",["data"=>$data,"category"=>"customers"]);
		}
		else
		{
			abort(404);
		}
	}
	
	public function delete_data($category,$key)
	{
		$this->login_ck();
		if($category=="products")
		{
			products::where('productCode',$key)->delete();
		}
		else if($category=="customers")
		{
			customers::where('customerNumber',$key)->delete();
		}
		else
		{
			abort(404);
		}
		return $this->show($category);
	}
	
	public function add_comple(Request $request,$category)
	{
		$this->login_ck();
		
		if($category=="products")
		{
			$validatedData = Validator::make($request->all(),[
												'productCode' => ['required','max:255','unique:products'],
												'productName' => ['required','string'],
												'productLine' => ['required','string','exists:productlines,productline'],
												'productScale' => ['required'],
												'productVendor' => ['required','string'],
												'productDescription' => ['required','string'],
												'quantityInStock' => ['required'],
												'buyPrice' => ['required'],
												'MSRP' => ['required'],
												]);
			if ($validatedData->fails())
			{
				return redirect()->back()->withErrors($validatedData->errors())->withInput();
			}
			
			products::create([
				 'productCode' => $request->input('productCode'),
				 'productName' => $request->input('productName'),
				 'productLine' => $request->input('productLine'),
				 'productScale' => $request->input('productScale'),
				 'productVendor' => $request->input('productVendor'),
				 'productDescription' => $request->input('productDescription'),
				 'quantityInStock' => $request->input('quantityInStock'),
				 'buyPrice' => $request->input('buyPrice'),
				 'MSRP' => $request->input('MSRP')
				 ]);
				 
				 $data = products::where('productCode', '=', $request->input('productCode'))->first();
				 return view("product_detail",["data"=>$data,"category"=>"products"]);
		}
		else if($category=="customers")
		{
			$validatedData = Validator::make($request->all(),[
												'customerNumber' => ['required','max:255','numeric','unique:customers'],
												'customerName' => ['required','string'],
												'contactLastName' => ['required','string'],
												'contactFirstName' => ['required','string'],
												'phone' => ['required'],
												'addressLine1' => ['required'],
												'addressLine2' => ['required'],
												'city' => ['required'],
												'state' => ['required'],
												'postalCode' => ['required'],
												'country' => ['required'],
												'salesRepEmployeeNumber' => ['required','exists:employees,employeeNumber','numeric'],
												'creditLimit' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
												]);
			if ($validatedData->fails())
			{
				return redirect()->back()->withErrors($validatedData->errors())->withInput();
			}
			
			customers::create([
				 'customerNumber' => $request->input('customerNumber'),
				 'customerName' => $request->input('customerName'),
				 'contactLastName' => $request->input('contactLastName'),
				 'contactFirstName' => $request->input('contactFirstName'),
				 'phone' => $request->input('phone'),
				 'addressLine1' => $request->input('addressLine1'),
				 'addressLine2' => $request->input('addressLine2'),
				 'city' => $request->input('city'),
				 'state' => $request->input('state'),
				 'postalCode' => $request->input('postalCode'),
				 'country' => $request->input('country'),
				 'salesRepEmployeeNumber' => $request->input('salesRepEmployeeNumber'),
				 'creditLimit' => $request->input('creditLimit')
				 ]);
				 
				 $data = customers::where('customerNumber', '=', $request->input('customerNumber'))->first();
				 return view("customer_detail",["data"=>$data,"category"=>"customers"]);
		}
		else
		{
			abort(404);
		}
	}
	
	public function products_fillter($colum,$fillter)
    {
		if($colum == "productVendor")
		{
			$colum = ["productCode","productName","buyPrice","quantityInStock","productVendor"];
			$data = products::where('productVendor', '=', $fillter)->paginate(25);
		}
		else if($colum == "productScale")
		{
			$colum = ["productCode","productName","buyPrice","quantityInStock","productVendor"];
			$data = products::where('productScale', '=', $fillter)->paginate(25);
		}
        return view("main",["data"=>$data,"colum"=>$colum,"category"=>"products"]);
    }
	
	public function products_details($productCode)
	{
		$data = products::where('productCode', '=', $productCode)->first();
		return view("product_detail",["data"=>$data,"category"=>"products"]);
	}
	
	public function employees_details($employeeNumber)
	{
		$data_em = employees::where("employeeNumber",'=',$employeeNumber)->first();
		$data_off = employees::where("employeeNumber",'=',$employeeNumber)->first()->offices; 
		return view("employees_detail",["data_em"=>$data_em,"data_off"=>$data_off,"category"=>"employees"]);
	}
	
	public function customers_details($customerNumber)
	{
		$data = customers::where("customerNumber",'=',$customerNumber)->first();
		return view("customer_detail",["data"=>$data,"category"=>"customers"]);
	}
	
	public static function display_catelog()
	{	
		echo 	"<ul class=\"ul-menu-list\">
				<li class=\"li-menu-list\"><a class=\"main-catelog\" href=\"#home\">Catelog</a></li>
				<li class=\"li-menu-list\"><a class=\"sub-catelog\" href=\"#news\">Product Vendor</a></li>";

		$result = products::distinct()->get("productVendor");
		foreach($result as $data)
		{
			echo "<li class='li-menu-list'><a href='http://localhost:8000/project/products/fillter/productVendor/".$data['productVendor']."'>".$data['productVendor']."</a></li>";
		}
		
		echo "<li class=\"li-menu-list\"><a class=\"sub-catelog\" href=\"#news\">Product Scale</a></li>";

		$result =  products::distinct()->get("productScale");
		foreach($result as $data)
		{
			echo "<li class='li-menu-list'><a href='http://localhost:8000/project/products/fillter/productScale/".$data['productScale']."'>".$data['productScale']."</a></li>";
		}
				
		echo "</ul>";
	}	
}