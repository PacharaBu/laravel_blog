<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\products;
use App\employees;
use App\customers;
use App\orders;
use App\orderdetails;
use App\productlines;
use App\login;


use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class database_project_controller extends Controller
{
	public function em_rank($target_rank)
	{
		if(strpos($target_rank,"Sales Rep") !== false)
		{
			return array(1,"Sales Manager","Sales Rep");
		}
		else if(strpos($target_rank,"Sales Manager") !== false)
		{
			return array(2,"Sales Manager","Sales Rep");
		}
		else if(strpos($target_rank,"VP") !== false)
		{
			return array(3,"VP","VP");
		}
		else if(strpos($target_rank,"President") !== false)
		{
			return array(4,"President","President");
		}
	}	

	public static function ck_rank($target_rank)
	{
		if((new static)->em_rank(auth()->user()->employees['jobTitle'])[0] > (new static)->em_rank($target_rank)[0])
		{
			return true;
		}
		else
		{
			return false;
		}
	}		
	
	public function login_ck()
	{
		//return view("login");
		if(auth()->guard()->guest())
		{
			header('Location: http://localhost:8000/login');
			exit;
		}
	}
	
	public function login()
	{
		//return view("login");
	}
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
		if($id=="products")
		{
			$colum = ["productCode","productName","buyPrice","quantityInStock","productVendor"];
			$data = products::where('is_active', '=', true)->paginate(25);
		}
		else if($id=="orders")
		{
			$colum = ["orderNumber","customerNumber","orderDate","comments","status"];
			$data = orders::paginate(20);
		}
		else if($id=="customers")
		{
			$colum = ["customerNumber","customerName","phone","salesRepEmployeeNumber","creditLimit"];
			$data = customers::where('is_active', '=', true)->paginate(25);
		}
		else if($id=="employees")
		{
			$colum = ["employeeNumber","firstName","lastName","officeCode","jobTitle"];
			$data = employees::where('is_active', '=', true)->paginate(25);
		}
		else
		{
			abort(404);
		}
        return view("main",["data"=>$data,"colum"=>$colum,"category"=>$id]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
	
	public function add($category)
	{
		if($category=="products")
		{
			return view('add_product',["category"=>$category]);
		}
		else if($category=="customers")
		{
			return view('add_customer',["category"=>$category]);
		}
		else if($category=="orders")
		{
			$product = products::where('is_active','=', true)->select('productCode','MSRP')->get();
			echo json_encode($product);
			return view('add_order',["category"=>$category,"product"=>$product]);
		}
		else
		{
			abort(404);
		}
	}
	
	public function edit_data($category,$key)
	{
		if($category=="products")
		{
			$pk = products::where('productCode', '=', $key)->first();
			if($pk==null)
			{
				abort(404);
			}
			
			$old = products::where('productCode', '=', $key)->first();
			
			return view("edit_product",["category"=>$category,"key"=>$key,"old"=>$old]);
		}
		else if($category=="customers")
		{
			$pk = customers::where('customerNumber', '=', $key)->first();
			if($pk==null)
			{
				abort(404);
			}
			
			$old = customers::where('customerNumber', '=', $key)->first();
			
			return view("edit_customer",["category"=>$category,"key"=>$key,"old"=>$old]);
		}
		else if($category=="employees")
		{
			$pk = employees::where('employeeNumber', '=', $key)->first();
			if($pk==null)
			{
				abort(404);
			}
			
			$old_em = employees::where('employeeNumber', '=', $key)->first();
			$old_off = employees::where("employeeNumber",'=',$key)->first()->offices; 
			if($this->ck_rank($old_em['jobTitle']))
			{
				return view("edit_employees",["category"=>$category,"key"=>$key,"old_em"=>$old_em,"old_off"=>$old_off]);
			}
			else
			{
				return $this->employees_details($key);
			}
		}
		else
		{
			abort(404);
		}
	}

	public function edit_comple(Request $request,$category,$key)
	{
		$this->login_ck();
		if($category=="products")
		{
			$validatedData = Validator::make($request->all(),[
												'productName' => ['required','string'],
												'productLine' => ['required','string','exists:productlines,productline'],
												'productScale' => ['required','string'],
												'productVendor' => ['required','string'],
												'productDescription' => ['required','string'],
												'quantityInStock' => ['required','digits_between:0,5'],
												'buyPrice' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
												'MSRP' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
												]);
			if ($validatedData->fails())
			{
				return redirect()->back()->withErrors($validatedData->errors());
			}
			
			products::where('productCode',$key)->update([
				 'productName' => $request->input('productName'),
				 'productLine' => $request->input('productLine'),
				 'productScale' => $request->input('productScale'),
				 'productVendor' => $request->input('productVendor'),
				 'productDescription' => $request->input('productDescription'),
				 'quantityInStock' => $request->input('quantityInStock'),
				 'buyPrice' => $request->input('buyPrice'),
				 'MSRP' => $request->input('MSRP')
				 ]);
				 
			$data = products::where('productCode', '=', $key)->first();
			return view("product_detail",["data"=>$data,"category"=>"products"]);
		}
		else if($category=="customers")
		{
			$validatedData = Validator::make($request->all(),[
												'customerName' => ['required','string'],
												'contactLastName' => ['required','string'],
												'contactFirstName' => ['required','string'],
												'phone' => ['required'],
												'addressLine1' => ['required'],
												'addressLine2' => ['required'],
												'city' => ['required'],
												'state' => ['required'],
												'postalCode' => ['required'],
												'country' => ['required'],
												'salesRepEmployeeNumber' => ['required','exists:employees,employeeNumber','numeric'],
												'creditLimit' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
												]);
			if ($validatedData->fails())
			{
				return redirect()->back()->withErrors($validatedData->errors())->withInput();
			}
			
			customers::where('customerNumber',$key)->update([
				 'customerName' => $request->input('customerName'),
				 'contactLastName' => $request->input('contactLastName'),
				 'contactFirstName' => $request->input('contactFirstName'),
				 'phone' => $request->input('phone'),
				 'addressLine1' => $request->input('addressLine1'),
				 'addressLine2' => $request->input('addressLine2'),
				 'city' => $request->input('city'),
				 'state' => $request->input('state'),
				 'postalCode' => $request->input('postalCode'),
				 'country' => $request->input('country'),
				 'salesRepEmployeeNumber' => $request->input('salesRepEmployeeNumber'),
				 'creditLimit' => $request->input('creditLimit')
				 ]);
				 
				 $data = customers::where('customerNumber', '=', $key)->first();
				 return view("customer_detail",["data"=>$data,"category"=>"customers"]);
		}
		else if($category=="employees")
		{
			$temp = array();
			$target_territory = employees::where("employeeNumber",'=',$key)->first()->offices['territory']; 
			$all_job = ['VP Marketing','VP Sales',"Sales Manager (".$target_territory.")",'Sales Rep'];
			foreach($all_job as $job)
			{
				if($this->ck_rank($job))
				{
					array_push($temp,$job); 
				}
			}
			$validatedData = Validator::make($request->all(),[
												'new_job' => ['required','string',Rule::in($temp)],
												]);
			if ($validatedData->fails())
			{
				return redirect()->back()->withErrors($validatedData->errors())->withInput();
			}
			
			employees::where('employeeNumber',$key)->update([
				 'jobTitle' => $request->input('new_job')
				 ]);
				 
			return $this->employees_details($key);
				 
		}			
		else
		{
			abort(404);
		}
	}
	
	public function delete_data($category,$key)
	{
		$this->login_ck();
		if($category=="products")
		{
			products::where('productCode',$key)->update([
				 'is_active' => false
				 ]);
		}
		else if($category=="customers")
		{
			customers::where('customerNumber',$key)->update([
				 'is_active' => false
				 ]);
		}	
		else if($category=="employees")
		{
			employees::where('employeeNumber',$key)->update([
				 'is_active' => false
				 ]);
				 
			login::where('employeeNumber',$key)->delete();
		}			
		else
		{
			abort(404);
		}
		return $this->show($category);
	}
	
	public function add_comple(Request $request,$category)
	{
		$this->login_ck();
		
		if($category=="products")
		{
			$validatedData = Validator::make($request->all(),[
												'productCode' => ['required','max:255','unique:products'],
												'productName' => ['required','string'],
												'productLine' => ['required','string','exists:productlines,productline'],
												'productScale' => ['required','string'],
												'productVendor' => ['required','string'],
												'productDescription' => ['required','string'],
												'quantityInStock' => ['required','digits_between:0,5'],
												'buyPrice' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
												'MSRP' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
												]);
			if ($validatedData->fails())
			{
				return redirect()->back()->withErrors($validatedData->errors())->withInput();
			}
			
			products::create([
				 'productCode' => $request->input('productCode'),
				 'productName' => $request->input('productName'),
				 'productLine' => $request->input('productLine'),
				 'productScale' => $request->input('productScale'),
				 'productVendor' => $request->input('productVendor'),
				 'productDescription' => $request->input('productDescription'),
				 'quantityInStock' => $request->input('quantityInStock'),
				 'buyPrice' => $request->input('buyPrice'),
				 'MSRP' => $request->input('MSRP')
				 ]);
				 
				 $data = products::where('productCode', '=', $request->input('productCode'))->first();
				 return view("product_detail",["data"=>$data,"category"=>"products"]);
		}
		else if($category=="customers")
		{
			$validatedData = Validator::make($request->all(),[
												'customerNumber' => ['required','max:255','numeric','unique:customers'],
												'customerName' => ['required','string'],
												'contactLastName' => ['required','string'],
												'contactFirstName' => ['required','string'],
												'phone' => ['required'],
												'addressLine1' => ['required'],
												'addressLine2' => ['required'],
												'city' => ['required'],
												'state' => ['required'],
												'postalCode' => ['required'],
												'country' => ['required'],
												'salesRepEmployeeNumber' => ['required','exists:employees,employeeNumber','numeric'],
												'creditLimit' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
												]);
			if ($validatedData->fails())
			{
				return redirect()->back()->withErrors($validatedData->errors())->withInput();
			}
			
			customers::create([
				 'customerNumber' => $request->input('customerNumber'),
				 'customerName' => $request->input('customerName'),
				 'contactLastName' => $request->input('contactLastName'),
				 'contactFirstName' => $request->input('contactFirstName'),
				 'phone' => $request->input('phone'),
				 'addressLine1' => $request->input('addressLine1'),
				 'addressLine2' => $request->input('addressLine2'),
				 'city' => $request->input('city'),
				 'state' => $request->input('state'),
				 'postalCode' => $request->input('postalCode'),
				 'country' => $request->input('country'),
				 'salesRepEmployeeNumber' => $request->input('salesRepEmployeeNumber'),
				 'creditLimit' => $request->input('creditLimit')
				 ]);
				 
				 $data = customers::where('customerNumber', '=', $request->input('customerNumber'))->first();
				 return view("customer_detail",["data"=>$data,"category"=>"customers"]);
		}
		else
		{
			abort(404);
		}
	}
	
	public function products_fillter($colum,$fillter)
    {
		if($colum == "productVendor")
		{
			$colum = ["productCode","productName","buyPrice","quantityInStock","productVendor"];
			$data = products::where('productVendor', '=', $fillter)->paginate(25);
		}
		else if($colum == "productScale")
		{
			$colum = ["productCode","productName","buyPrice","quantityInStock","productVendor"];
			$data = products::where('productScale', '=', $fillter)->paginate(25);
		}
        return view("main",["data"=>$data,"colum"=>$colum,"category"=>"products"]);
    }
	
	public function products_details($productCode)
	{
		$data = products::where('productCode', '=', $productCode)->first();
		return view("product_detail",["data"=>$data,"category"=>"products"]);
	}
	
	public function employees_details($employeeNumber)
	{
		$data_em = employees::where("employeeNumber",'=',$employeeNumber)->first();
		$data_off = employees::where("employeeNumber",'=',$employeeNumber)->first()->offices; 
		return view("employees_detail",["data_em"=>$data_em,"data_off"=>$data_off,"category"=>"employees"]);
	}

	public function employees_promote($employeeNumber)
	{
		$data_em = employees::where("employeeNumber",'=',$employeeNumber)->first();
		$this->login_ck();
		if($this->ck_rank($data_em['jobTitle']))
		{
			employees::where('employeeNumber',$employeeNumber)->update([
				 'jobTitle' => $this->em_rank($data_em['jobTitle'])[1]
				 ]);			
		}
		return $this->show("employees");
	}
	
	public function employees_demote($employeeNumber)
	{
		$data_em = employees::where("employeeNumber",'=',$employeeNumber)->first();
		$this->login_ck();
		if($this->ck_rank($data_em['jobTitle']))
		{
			employees::where('employeeNumber',$employeeNumber)->update([
				 'jobTitle' => $this->em_rank($data_em['jobTitle'])[2]
				 ]);			
		}
		return $this->show("employees");
	}
	
	public function customers_details($customerNumber)
	{
		$data = customers::where("customerNumber",'=',$customerNumber)->first();
		return view("customer_detail",["data"=>$data,"category"=>"customers"]);
	}
	
	public function orders_details($orderNumber)
	{
		$data_or = orders::where("orderNumber",'=',$orderNumber)->first();
		$data_cu = orders::where("orderNumber",'=',$orderNumber)->first()->customers; 
		$data_or_de = orders::where("orderNumber",'=',$orderNumber)->first()->orderdetails; 
		foreach($data_or_de as $index => $product_code)
			{
				$data_pr[$index] = $product_code->products['productName']; 
			}
		#echo $data_or_de;
		#echo $data_pr[0];
		return view("order_detail",["data_or"=>$data_or,"data_cu"=>$data_cu,"data_or_de"=>$data_or_de,"data_pr"=>$data_pr,"category"=>"orders"]);
	}
	
	public static function display_catelog()
	{	
		echo 	"<ul class=\"ul-menu-list\">
				<li class=\"li-menu-list\"><a class=\"main-catelog\" href=\"#home\">Catelog</a></li>
				<li class=\"li-menu-list\"><a class=\"sub-catelog\" href=\"#news\">Product Vendor</a></li>";

		$result = products::where('is_active', '=', true)->distinct()->get("productVendor");
		foreach($result as $data)
		{
			echo "<li class='li-menu-list'><a href='http://localhost:8000/project/products/fillter/productVendor/".$data['productVendor']."'>".$data['productVendor']."</a></li>";
		}
		
		echo "<li class=\"li-menu-list\"><a class=\"sub-catelog\" href=\"#news\">Product Scale</a></li>";

		$result =  products::where('is_active', '=', true)->distinct()->get("productScale");
		foreach($result as $data)
		{
			echo "<li class='li-menu-list'><a href='http://localhost:8000/project/products/fillter/productScale/".$data['productScale']."'>".$data['productScale']."</a></li>";
		}
				
		echo "</ul>";
	}

	public static function hollow($category)
	{
		if($category=="products")
		{
			$colum = ["productCode","productName","buyPrice","quantityInStock","productVendor"];
			$data = products::where('is_active', '=', false)->paginate(25);;
		}
		else if($category=="customers")
		{
			$colum = ["customerNumber","customerName","phone","salesRepEmployeeNumber","creditLimit"];
			$data = customers::where('is_active', '=', false)->paginate(25);;
		}
		else if($category=="employees")
		{
			$colum = ["employeeNumber","firstName","lastName","officeCode","jobTitle"];
			$data = employees::where('is_active', '=', false)->paginate(25);;
		}
		else
		{
			abort(404);
		}
        return view("hollow",["data"=>$data,"colum"=>$colum,"category"=>$category]);
	}		
}