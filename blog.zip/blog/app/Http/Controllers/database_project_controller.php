<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\products;
use App\employees;
use App\customers;
use App\orders;
use App\orderdetails;
use App\productlines;
use App\payments;
use App\login;
use App\cart;
use App\product_in_cart;
use App\promotion;


use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class database_project_controller extends Controller
{
	public function em_rank($target_rank)
	{
		if(strpos($target_rank,"Sales Rep") !== false)
		{
			return array(1,"Sales Manager","Sales Rep");
		}
		else if(strpos($target_rank,"Sales Manager") !== false)
		{
			return array(2,"Sales Manager","Sales Rep");
		}
		else if(strpos($target_rank,"VP") !== false)
		{
			return array(3,"VP","VP");
		}
		else if(strpos($target_rank,"President") !== false)
		{
			return array(4,"President","President");
		}
	}

	public static function ck_preorder($productCode)
	{
		$ck = products::where("productCode","=",$productCode)->get("is_preorder");
		if($ck[0]['is_preorder']=="T")
		{
			return true;
		}	
		else
		{
			return false;
		}
	}	
	
	public static function ck_promotion($productCode)
	{
		$ck = promotion::where([["productCode","=",$productCode],["expiry date",">=",date("y-m-d")]])->count();
		if($ck>0)
		{
			return true;
		}	
		else
		{
			return false;
		}
	}

	public static function ck_rank($target_rank)
	{
		if((new static)->em_rank(auth()->user()->employees['jobTitle'])[0] > (new static)->em_rank($target_rank)[0])
		{
			return true;
		}
		else
		{
			return false;
		}
	}		
	
	public function login_ck()
	{
		//return view("login");
		if(auth()->guard()->guest())
		{
			header('Location: http://localhost:8000/login');
			exit;
		}
	}
	
	public function login()
	{
		//return view("login");
	}
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
		if($id=="products")
		{
			$colum = ["productCode","productName","buyPrice","quantityInStock","productVendor","is_preorder"];
			$data = products::where('is_active', '=', true)->paginate(25);
		}
		else if($id=="orders")
		{
			$colum = ["orderNumber","customerNumber","orderDate","comments","status"];
			$data = orders::paginate(20);
		}
		else if($id=="customers")
		{
			$colum = ["customerNumber","customerName","phone","salesRepEmployeeNumber","creditLimit"];
			$data = customers::where('is_active', '=', true)->paginate(25);
		}
		else if($id=="employees")
		{
			$colum = ["employeeNumber","firstName","lastName","officeCode","jobTitle"];
			$data = employees::where('is_active', '=', true)->paginate(25);
		}
		else if($id=="payments")
		{
			$colum = ['customerNumber','checkNumber','paymentDate','amount','member_point'];
			$data = payments::paginate(25);
		}
		else if($id=="promotion")
		{
			$colum = ['productCode','expiry date'];
			$data = promotion::paginate(25);
		}
		else
		{
			abort(404);
		}
        return view("main",["data"=>$data,"colum"=>$colum,"category"=>$id]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
	
	public function add($category,$key=0)
	{
		if($category=="products")
		{
			return view('add_product',["category"=>$category]);
		}
		else if($category=="customers")
		{
			return view('add_customer',["category"=>$category]);
		}
		else if($category=="orders")
		{
			$select_product = product_in_cart::where('orderNumber','=', $key)->get();
			$ck = product_in_cart::where('orderNumber','=', $key)->count();
			if($ck>0)
			{
				return view('add_order',["category"=>$category,"key"=>$key,"select_product"=>$select_product]);
			}
			else
			{
				return redirect()->to("http://localhost:8000/project/add/product_to_cart/".$key);
			}
		}
		else if($category=="payments")
		{
			return view('add_payments',["category"=>$category]);
		}
		else if($category=="promotion")
		{
			return view('add_promotion',["category"=>$category]);
		}
		else if($category=="product_to_cart")
		{
			$select_product = product_in_cart::where('orderNumber','=', $key)->get();
			$product = products::where('is_active', '=', true)->get();
			return view('add_product_to_cart',["category"=>$category,"select_product"=>$select_product,"product"=>$product,"key"=>$key]);
		}
		else if($category=="cart")
		{
			return view('add_cart',["category"=>$category]);
		}
		else
		{
			abort(404);
		}
	}
	
	public function edit_data($category,$key)
	{
		if($category=="products")
		{
			$pk = products::where('productCode', '=', $key)->first();
			if($pk==null)
			{
				abort(404);
			}
			
			$old = products::where('productCode', '=', $key)->first();
			
			return view("edit_product",["category"=>$category,"key"=>$key,"old"=>$old]);
		}
		else if($category=="customers")
		{
			$pk = customers::where('customerNumber', '=', $key)->first();
			if($pk==null)
			{
				abort(404);
			}
			
			$old = customers::where('customerNumber', '=', $key)->first();
			
			return view("edit_customer",["category"=>$category,"key"=>$key,"old"=>$old]);
		}
		else if($category=="employees")
		{
			$pk = employees::where('employeeNumber', '=', $key)->first();
			if($pk==null)
			{
				abort(404);
			}
			
			$old_em = employees::where('employeeNumber', '=', $key)->first();
			$old_off = employees::where("employeeNumber",'=',$key)->first()->offices; 
			if($this->ck_rank($old_em['jobTitle']))
			{
				return view("edit_employees",["category"=>$category,"key"=>$key,"old_em"=>$old_em,"old_off"=>$old_off]);
			}
			else
			{
				return $this->employees_details($key);
			}
		}
		else if($category=="orders")
		{
			$pk = orders::where('orderNumber', '=', $key)->first();
			if($pk==null)
			{
				abort(404);
			}
			$old = orders::where('orderNumber', '=', $key)->first();
			#echo json_encode($old);
			
			return view("edit_order",["category"=>$category,"key"=>$key,"old"=>$old]);
			
		}
		else
		{
			abort(404);
		}
	}

	public function edit_comple(Request $request,$category,$key)
	{
		$this->login_ck();
		if($category=="products")
		{
			if($this->ck_preorder($key)==false)
			{
				echo "OK";
				$validatedData = Validator::make($request->all(),[
													'productName' => ['required','string'],
													'productLine' => ['required','string','exists:productlines,productline'],
													'productScale' => ['required','string'],
													'productVendor' => ['required','string'],
													'productDescription' => ['required','string'],
													'quantityInStock' => ['required','digits_between:0,5'],
													'buyPrice' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
													'MSRP' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
													]);
				if ($validatedData->fails())
				{
					return redirect()->back()->withErrors($validatedData->errors());
				}
				
				products::where('productCode',$key)->update([
					 'productName' => $request->input('productName'),
					 'productLine' => $request->input('productLine'),
					 'productScale' => $request->input('productScale'),
					 'productVendor' => $request->input('productVendor'),
					 'productDescription' => $request->input('productDescription'),
					 'quantityInStock' => $request->input('quantityInStock'),
					 'buyPrice' => $request->input('buyPrice'),
					 'MSRP' => $request->input('MSRP'),
					 'is_preorder' => "F",
					 ]);
			}
			else
			{	
				if($request->input('is_preorder')=="T")
				{
					$preorder = "T";
				}
				else
				{
					$preorder = "F";
				}
		
				$validatedData = Validator::make($request->all(),[
													'productName' => ['required','string'],
													'productLine' => ['required','string','exists:productlines,productline'],
													'productScale' => ['required','string'],
													'productVendor' => ['required','string'],
													'productDescription' => ['required','string'],
													'buyPrice' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
													'MSRP' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
													]);
				if ($validatedData->fails())
				{
					return redirect()->back()->withErrors($validatedData->errors());
				}
				
				products::where('productCode',$key)->update([
					 'productName' => $request->input('productName'),
					 'productLine' => $request->input('productLine'),
					 'productScale' => $request->input('productScale'),
					 'productVendor' => $request->input('productVendor'),
					 'productDescription' => $request->input('productDescription'),
					 'is_preorder' => $preorder,
					 'buyPrice' => $request->input('buyPrice'),
					 'MSRP' => $request->input('MSRP'),
					 ]);
				
			}
				 
			$data = products::where('productCode', '=', $key)->first();
			return view("product_detail",["data"=>$data,"category"=>"products"]);
		}
		else if($category=="customers")
		{
			$validatedData = Validator::make($request->all(),[
												'customerName' => ['required','string'],
												'contactLastName' => ['required','string'],
												'contactFirstName' => ['required','string'],
												'phone' => ['required'],
												'addressLine1' => ['required'],
												'addressLine2' => ['required'],
												'city' => ['required'],
												'state' => ['required'],
												'postalCode' => ['required'],
												'country' => ['required'],
												'salesRepEmployeeNumber' => ['required','exists:employees,employeeNumber','numeric'],
												'creditLimit' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
												]);
			if ($validatedData->fails())
			{
				return redirect()->back()->withErrors($validatedData->errors())->withInput();
			}
			
			customers::where('customerNumber',$key)->update([
				 'customerName' => $request->input('customerName'),
				 'contactLastName' => $request->input('contactLastName'),
				 'contactFirstName' => $request->input('contactFirstName'),
				 'phone' => $request->input('phone'),
				 'addressLine1' => $request->input('addressLine1'),
				 'addressLine2' => $request->input('addressLine2'),
				 'city' => $request->input('city'),
				 'state' => $request->input('state'),
				 'postalCode' => $request->input('postalCode'),
				 'country' => $request->input('country'),
				 'salesRepEmployeeNumber' => $request->input('salesRepEmployeeNumber'),
				 'creditLimit' => $request->input('creditLimit')
				 ]);
				 
				 $data = customers::where('customerNumber', '=', $key)->first();
				 return view("customer_detail",["data"=>$data,"category"=>"customers"]);
		}
		else if($category=="employees")
		{
			$temp = array();
			$target_territory = employees::where("employeeNumber",'=',$key)->first()->offices['territory']; 
			$all_job = ['VP Marketing','VP Sales',"Sales Manager (".$target_territory.")",'Sales Rep'];
			foreach($all_job as $job)
			{
				if($this->ck_rank($job))
				{
					array_push($temp,$job); 
				}
			}
			$validatedData = Validator::make($request->all(),[
												'new_job' => ['required','string',Rule::in($temp)],
												]);
			if ($validatedData->fails())
			{
				return redirect()->back()->withErrors($validatedData->errors())->withInput();
			}
			
			employees::where('employeeNumber',$key)->update([
				 'jobTitle' => $request->input('new_job')
				 ]);
				 
			return $this->employees_details($key);
				 
		}		
		else if($category=="orders")	
		{
			$all_status = ["Cancelled","Disputed","In Process","On hold","Resolved","Shipped"];
			$validatedData = Validator::make($request->all(),[
												'shippedDate' => ['required','date'],
												'comments' => ['required','string'],
												'status' => ['required',Rule::in($all_status)],
												]);
			if ($validatedData->fails())
			{
				return redirect()->back()->withErrors($validatedData->errors())->withInput();
			}
			
			orders::where('orderNumber',$key)->update([
				 'shippedDate' => $request->input('shippedDate'),
				 'comments' => $request->input('comments'),
				 'status' => $request->input('status')
				 ]);
				 
			return $this->orders_details($key);
		}			
		else
		{
			abort(404);
		}
	}
	
	public function delete_data($category,$key)
	{
		$this->login_ck();
		if($category=="products")
		{
			products::where('productCode',$key)->update([
				 'is_active' => false
				 ]);
		}
		else if($category=="customers")
		{
			customers::where('customerNumber',$key)->update([
				 'is_active' => false
				 ]);
		}	
		else if($category=="employees")
		{
			$job_title = employees::where('employeeNumber',$key)->get('jobTitle');
			if($job_title[0]['jobTitle']!="President")
			{
				employees::where('employeeNumber',$key)->update([
					'is_active' => false
					]);
				 
				login::where('employeeNumber',$key)->delete();
			}
		}	
		else if($category=="promotion")
		{
			promotion::where('productCode',$key)->delete();
		}			
		else
		{
			abort(404);
		}
		return $this->show($category);
	}
	
	public function add_comple(Request $request,$category)
	{
		$this->login_ck();
		
		if($category=="products")
		{
			if($request->input('is_preorder')=="T")
			{
				$validatedData = Validator::make($request->all(),[
													'productCode' => ['required','max:255','unique:products'],
													'productName' => ['required','string'],
													'productLine' => ['required','string','exists:productlines,productline'],
													'productScale' => ['required','string'],
													'productVendor' => ['required','string'],
													'productDescription' => ['required','string'],
													'buyPrice' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
													'MSRP' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
													]);
													
				if ($validatedData->fails())
				{
					return redirect()->back()->withErrors($validatedData->errors())->withInput();
				}
				
							
				products::create([
				 'productCode' => $request->input('productCode'),
				 'productName' => $request->input('productName'),
				 'productLine' => $request->input('productLine'),
				 'productScale' => $request->input('productScale'),
				 'productVendor' => $request->input('productVendor'),
				 'productDescription' => $request->input('productDescription'),
				 'quantityInStock' => 0,
				 'buyPrice' => $request->input('buyPrice'),
				 'MSRP' => $request->input('MSRP'),
				 'is_preorder' => "T"
				 ]);
			}
			else
			{
				$validatedData = Validator::make($request->all(),[
													'productCode' => ['required','max:255','unique:products'],
													'productName' => ['required','string'],
													'productLine' => ['required','string','exists:productlines,productline'],
													'productScale' => ['required','string'],
													'productVendor' => ['required','string'],
													'productDescription' => ['required','string'],
													'quantityInStock' => ['required','digits_between:0,5'],
													'buyPrice' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
													'MSRP' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
													]);
				if ($validatedData->fails())
				{
					return redirect()->back()->withErrors($validatedData->errors())->withInput();
				}
				
							
				products::create([
				 'productCode' => $request->input('productCode'),
				 'productName' => $request->input('productName'),
				 'productLine' => $request->input('productLine'),
				 'productScale' => $request->input('productScale'),
				 'productVendor' => $request->input('productVendor'),
				 'productDescription' => $request->input('productDescription'),
				 'quantityInStock' => $request->input('quantityInStock'),
				 'buyPrice' => $request->input('buyPrice'),
				 'MSRP' => $request->input('MSRP')
				 ]);
			}
				 
				 $data = products::where('productCode', '=', $request->input('productCode'))->first();
				 return view("product_detail",["data"=>$data,"category"=>"products"]);
		}
		else if($category=="customers")
		{
			$validatedData = Validator::make($request->all(),[
												'customerNumber' => ['required','max:255','numeric','unique:customers'],
												'customerName' => ['required','string'],
												'contactLastName' => ['required','string'],
												'contactFirstName' => ['required','string'],
												'phone' => ['required'],
												'addressLine1' => ['required'],
												'addressLine2' => ['required'],
												'city' => ['required'],
												'state' => ['required'],
												'postalCode' => ['required'],
												'country' => ['required'],
												'salesRepEmployeeNumber' => ['required','exists:employees,employeeNumber','numeric'],
												'creditLimit' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
												]);
			if ($validatedData->fails())
			{
				return redirect()->back()->withErrors($validatedData->errors())->withInput();
			}
			
			customers::create([
				 'customerNumber' => $request->input('customerNumber'),
				 'customerName' => $request->input('customerName'),
				 'contactLastName' => $request->input('contactLastName'),
				 'contactFirstName' => $request->input('contactFirstName'),
				 'phone' => $request->input('phone'),
				 'addressLine1' => $request->input('addressLine1'),
				 'addressLine2' => $request->input('addressLine2'),
				 'city' => $request->input('city'),
				 'state' => $request->input('state'),
				 'postalCode' => $request->input('postalCode'),
				 'country' => $request->input('country'),
				 'salesRepEmployeeNumber' => $request->input('salesRepEmployeeNumber'),
				 'creditLimit' => $request->input('creditLimit')
				 ]);
				 
				 $data = customers::where('customerNumber', '=', $request->input('customerNumber'))->first();
				 return view("customer_detail",["data"=>$data,"category"=>"customers"]);
		}
		else if($category=="orders")
		{
			$validatedData = Validator::make($request->all(),[
												'key' => ['required','digits_between:0,10','unique:orders,orderNumber'],
												'requiredDate' => ['required','date'],
												'shippedDate' => ['required','date'],
												'comments' => ['required','string'],
												'customerNumber' => ['required','exists:customers,customerNumber'],
												]);
			if ($validatedData->fails())
			{
				return redirect()->back()->withErrors($validatedData->errors())->withInput();
			}
			
			orders::create([
				 'orderNumber' => $request->input('key'),
				 'orderDate' => date('y-m-d'),
				 'requiredDate' => $request->input('requiredDate'),
				 'shippedDate' => $request->input('shippedDate'),
				 'status' => 'In Process',
				 'comments' => $request->input('comments'),
				 'customerNumber' => $request->input('customerNumber'),
				 ]);
			
			$select_product =  product_in_cart::where("orderNumber","=",$request->input('key'))->get();
			foreach($select_product as $index => $p)
			{
				orderdetails::create([
					'orderNumber' => $request->input('key'),
					'productCode' => $p['productCode'],
					'quantityOrdered' => $p['quantityOrdered'],
					'priceEach' => $p['priceEach'],
					'orderLineNumber' => $index+1
				 ]);
			}
			
			$total_price = $request->input('total_price');
			$member_point = floor(doubleval($total_price)/100)*3;
			
			customers::where("customerNumber","=",$request->input('customerNumber'))->increment('Total_Point',$member_point);
			
			 product_in_cart::where("orderNumber","=",$request->input('key'))->delete();
			 cart::where("orderNumber","=",$request->input('key'))->delete();
			 
			 return $this->orders_details($request->input('key'));
		}
		else if($category=="payments")
		{
			$validatedData = Validator::make($request->all(),[
												'customerNumber' => ['required','exists:customers,customerNumber'],
												'amount' => ['required','regex:/^\d{0,8}\.\d{2}$/'],
												]);
			
			$customerNumber = $request->input('customerNumber');
			$checkNumber = $request->input('checkNumber');
			
			$ck = payments::where([["customerNumber","=",$customerNumber],["checkNumber","=",$checkNumber]])->count();
			
			if ($validatedData->fails() or $ck > 0 or $customerNumber == null or $checkNumber == null)
			{
				return redirect()->back()->withErrors($validatedData->errors())->withInput();
			}
			
			payments::create([
					'customerNumber' => $request->input('customerNumber'),
					'checkNumber' => $request->input('checkNumber'),
					'paymentDate' => date('y-m-d'),
					'amount' => $request->input('amount'),
				 ]);
				 
			return $this->show('payments');
		}
		else if($category=="promotion")
		{
			$validatedData = Validator::make($request->all(),[
												'productCode' => ['required','exists:products,productCode'],
												'expiry_date' => ['required','date'],
												]);
												
			if ($validatedData->fails())
			{
				return redirect()->back()->withErrors($validatedData->errors())->withInput();
			}
			
			promotion::create([
					'productCode' => $request->input('productCode'),
					'expiry date' => $request->input('expiry_date'),
				 ]);
			
			return $this->show("promotion");
		}
		else if($category=="cart")
		{
			$validatedData = Validator::make($request->all(),[
												'orderNumber' => ['required','digits_between:0,10','unique:orders,orderNumber']
												]);
			if ($validatedData->fails())
			{
				return redirect()->back()->withErrors($validatedData->errors())->withInput();
			}
			
			$ck = cart::where("orderNumber","=",$request->input('orderNumber'))->count();
			if($ck==0)
			{
				cart::create(['orderNumber' => $request->input('orderNumber')]);
			}
			return $this->add("product_to_cart",$request->input('orderNumber'));
			
		}
		else
		{
			abort(404);
		}
	}
	
	public function products_fillter($colum,$fillter)
    {
		if($colum == "productVendor")
		{
			$colum = ["productCode","productName","buyPrice","quantityInStock","productVendor"];
			$data = products::where([['productVendor', '=', $fillter],['is_active','=','1']])->paginate(25);
		}
		else if($colum == "productScale")
		{
			$colum = ["productCode","productName","buyPrice","quantityInStock","productVendor"];
			$data = products::where([['productScale', '=', $fillter],['is_active','=','1']])->paginate(25);
		}
        return view("main",["data"=>$data,"colum"=>$colum,"category"=>"products"]);
    }
	
	public function products_details($productCode)
	{
		$data = products::where('productCode', '=', $productCode)->first();
		return view("product_detail",["data"=>$data,"category"=>"products"]);
	}
	
	public function employees_details($employeeNumber)
	{
		$data_em = employees::where("employeeNumber",'=',$employeeNumber)->first();
		$data_off = employees::where("employeeNumber",'=',$employeeNumber)->first()->offices; 
		return view("employees_detail",["data_em"=>$data_em,"data_off"=>$data_off,"category"=>"employees"]);
	}
	
	public function delete_form_cart(Request $request)
	{
		$this->login_ck();
		
		$qty_cart = product_in_cart::where([['orderNumber', '=', $request->input('key')],['productCode', '=', $request->input('productCode')]])->get('quantityOrdered');
		if($qty_cart[0]['quantityOrdered']>0)
		{
			if($this->ck_preorder($request->input('productCode'))==false)
			{
				products::where('productCode',$request->input('productCode'))->increment('quantityInStock',$qty_cart[0]['quantityOrdered']);
			}
		}
		
		product_in_cart::where([['orderNumber', '=', $request->input('key')],['productCode', '=', $request->input('productCode')]])->delete();
		
		return redirect()->to("http://localhost:8000/project/add/product_to_cart/".$request->input('key'));
	}
	
	public function add_to_cart(Request $request)
	{
		$this->login_ck();
			
		$validatedData = Validator::make($request->all(),[
													'key' => ['required'],
													'productCode' => ['required'],
													'productName' => ['required'],
													'quantity' => ['required','numeric','min:1'],
													'MSRP' => ['required'],
													]);

												
		if ($validatedData->fails())
		{
			return redirect()->to("http://localhost:8000/project/add/product_to_cart/".$request->input('key'));
		}
		
		$ck = product_in_cart::where([['orderNumber', '=', $request->input('key')],['productCode', '=', $request->input('productCode')]])->count();
		$qty_product = products::where('productCode',"=",$request->input('productCode'))->get('quantityInStock');
		if($qty_product[0]['quantityInStock']>=$request->input('quantity') or $this->ck_preorder($request->input('productCode')) == true)
		{
			if($ck>0)
			{
				$old_qty = product_in_cart::where([['orderNumber', '=', $request->input('key')],['productCode', '=', $request->input('productCode')]])->first()['quantityOrdered'];
				$qty =  $request->input('quantity') + $old_qty;
				product_in_cart::where([['orderNumber', '=', $request->input('key')],['productCode', '=', $request->input('productCode')]])->update([
					 'quantityOrdered' => $qty
					 ]);
			}
			else
			{
				product_in_cart::create(['orderNumber' => $request->input('key'),
												  'productCode' => $request->input('productCode'),
												  'productName' => $request->input('productName'),
												  'quantityOrdered' => $request->input('quantity'),
												  'priceEach' => $request->input('MSRP')
												  ]);
			}
			if($this->ck_preorder($request->input('productCode'))==false)
			{
				products::where('productCode',$request->input('productCode'))->decrement('quantityInStock',$request->input('quantity'));
			}
		}

		return redirect()->to("http://localhost:8000/project/add/product_to_cart/".$request->input('key'));		
	}

	public function employees_promote($employeeNumber)
	{
		$data_em = employees::where("employeeNumber",'=',$employeeNumber)->first();
		$this->login_ck();
		if($this->ck_rank($data_em['jobTitle']))
		{
			employees::where('employeeNumber',$employeeNumber)->update([
				 'jobTitle' => $this->em_rank($data_em['jobTitle'])[1]
				 ]);			
		}
		return $this->show("employees");
	}
	
	public function employees_demote($employeeNumber)
	{
		$data_em = employees::where("employeeNumber",'=',$employeeNumber)->first();
		$this->login_ck();
		if($this->ck_rank($data_em['jobTitle']))
		{
			employees::where('employeeNumber',$employeeNumber)->update([
				 'jobTitle' => $this->em_rank($data_em['jobTitle'])[2]
				 ]);			
		}
		return $this->show("employees");
	}
	
	public function customers_details($customerNumber)
	{
		$data = customers::where("customerNumber",'=',$customerNumber)->first();
		return view("customer_detail",["data"=>$data,"category"=>"customers"]);
	}
	
	public function orders_details($orderNumber)
	{
		$data_or = orders::where("orderNumber",'=',$orderNumber)->first();
		$data_cu = orders::where("orderNumber",'=',$orderNumber)->first()->customers; 
		$data_or_de = orders::where("orderNumber",'=',$orderNumber)->first()->orderdetails; 
		foreach($data_or_de as $index => $product_code)
			{
				$data_pr[$index] = $product_code->products['productName']; 
			}
		#echo $data_or_de;
		#echo $data_pr[0];
		return view("order_detail",["data_or"=>$data_or,"data_cu"=>$data_cu,"data_or_de"=>$data_or_de,"data_pr"=>$data_pr,"category"=>"orders"]);
	}
	
	public static function display_catelog()
	{	
		echo 	"<ul class=\"ul-menu-list\">
				<li class=\"li-menu-list\"><a class=\"main-catelog\" href=\"#home\">Catelog</a></li>
				<li class=\"li-menu-list\"><a class=\"sub-catelog\" href=\"#news\">Product Vendor</a></li>";

		$result = products::where('is_active', '=', true)->distinct()->get("productVendor");
		foreach($result as $data)
		{
			echo "<li class='li-menu-list'><a href='http://localhost:8000/project/products/fillter/productVendor/".$data['productVendor']."'>".$data['productVendor']."</a></li>";
		}
		
		echo "<li class=\"li-menu-list\"><a class=\"sub-catelog\" href=\"#news\">Product Scale</a></li>";

		$result =  products::where('is_active', '=', true)->distinct()->get("productScale");
		foreach($result as $data)
		{
			echo "<li class='li-menu-list'><a href='http://localhost:8000/project/products/fillter/productScale/".$data['productScale']."'>".$data['productScale']."</a></li>";
		}
				
		echo "</ul>";
	}

	public static function hollow($category)
	{
		if($category=="products")
		{
			$colum = ["productCode","productName","buyPrice","quantityInStock","productVendor"];
			$data = products::where('is_active', '=', false)->paginate(25);;
		}
		else if($category=="customers")
		{
			$colum = ["customerNumber","customerName","phone","salesRepEmployeeNumber","creditLimit"];
			$data = customers::where('is_active', '=', false)->paginate(25);;
		}
		else if($category=="employees")
		{
			$colum = ["employeeNumber","firstName","lastName","officeCode","jobTitle"];
			$data = employees::where('is_active', '=', false)->paginate(25);;
		}
		else
		{
			abort(404);
		}
        return view("hollow",["data"=>$data,"colum"=>$colum,"category"=>$category]);
	}		
}