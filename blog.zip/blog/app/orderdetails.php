<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

class orderdetails extends Model
{
    public $table = 'orderdetails';
	
	protected function setKeysForSaveQuery(Builder $query)
    {
        $query
            ->where('orderNumber', '=', $this->getAttribute('orderNumber'))
            ->where('productCode', '=', $this->getAttribute('productCode'));
        return $query;
    }
	
	public function products()
	{
		return $this->hasOne('App\products','productCode','productCode');
	}
}
