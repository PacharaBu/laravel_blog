<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

class payments extends Model
{
	public $timestamps = false;
	
    public $table = 'payments';
	
	protected function setKeysForSaveQuery(Builder $query)
    {
        $query
            ->where('customerNumber', '=', $this->getAttribute('customerNumber'))
            ->where('checkNumber', '=', $this->getAttribute('checkNumber'));
        return $query;
    }
	
	protected $fillable = ['customerNumber','checkNumber','paymentDate','amount'];
	
}
?>