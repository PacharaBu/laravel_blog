<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class offices extends Model
{
    public $table = 'offices';
	public $key = 'officeCode';
}
