<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class customers extends Model
{
	public $timestamps = false;
	
    public $table = 'customers';
	public $key = 'customerNumber';
	
	protected $fillable = ['customerNumber','customerName','contactLastName','contactFirstName','phone','addressLine1','addressLine2','city','state','postalCode','country','salesRepEmployeeNumber','creditLimit'];
}
