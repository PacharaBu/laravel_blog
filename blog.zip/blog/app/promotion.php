<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class promotion extends Model
{
	public $timestamps = false;
	
    public $table = 'promotion';
	public $key = 'expiry date';
	
	protected $fillable = ['productCode','expiry date'];
	
}
?>