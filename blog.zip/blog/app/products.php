<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class products extends Model
{
	public $timestamps = false;
	
    public $table = 'products';
	public $key = 'productCode';
	
	protected $fillable = ['productCode','productName','productLine','productScale','productVendor','productDescription','quantityInStock','buyPrice','MSRP'];
	
}
