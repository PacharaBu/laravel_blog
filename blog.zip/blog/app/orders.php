<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class orders extends Model
{
    public $table = 'orders';
	public $key = 'orderNumber';
}
