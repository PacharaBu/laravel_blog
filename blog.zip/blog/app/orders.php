<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Awobaz\Compoships\Compoships;

class orders extends Model
{
	public $timestamps = false;
	
    public $table = 'orders';
	public $key = 'orderNumber';
	
	protected $fillable = ['orderNumber','orderDate','requiredDate','shippedDate','status','comments','customerNumber'];
	
	public function customers()
	{
		return $this->hasOne('App\customers','customerNumber','customerNumber');
	}
	
	public function orderdetails()
	{
		return $this->hasMany('App\orderdetails', 'orderNumber', 'orderNumber');
	}

}
