<?php if(auth()->guard()->guest()): ?>
<?php
	header('Location: http://localhost:8000/login');
	exit;
?>
<?php else: ?>
<html>
    <head>
        <title>EDIT<?php echo e($key); ?></title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="http://localhost/laravel/blog/resources/views/css/main.css"> <!--import css file-->
    </head>
    <body class="bg-image">
        <div class="row">
            <div class="column-left"><img src="http://localhost/laravel/blog/resources/views/image/logo.png" class="login-logo-image"></div>
            <div class="column-center"><h1>Company name</h1></div>
            <div class="column-right">
			<?php if(auth()->guard()->guest()): ?>
			<?php else: ?>
                <b>Employee code:</b><?php echo e(Auth::user()->employeeNumber); ?><br>
                <b>Employee name:</b><?php echo Auth::user()->employees['firstName'],Auth::user()->employees['lastName'] ?><br>
                <b>Department:</b><?php echo e(Auth::user()->employees['jobTitle']); ?>

			<?php endif; ?>
            </div>
        </div>
        <ul class="ul-menu-bar">
		<?php if(auth()->guard()->guest()): ?>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/products">products</a></li>
			<li class="li-menu-bar" style="float:right"><a href="<?php echo e(route('login')); ?>">Login</a></li>
			<li class="li-menu-bar" style="float:right"><a href="<?php echo e(route('register')); ?>">Register</a></li>
		<?php else: ?>
			<li class="li-menu-bar"><a href="http://localhost:8000/project/products">products</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/orders">orders</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/customers">customers</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/employees">employees</a></li>
            <li class="li-menu-bar" style="float:right"><a class="active" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">logout</a></li>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
		<?php endif; ?>
        </ul>
		<div class="row" style="margin:0px">
			<div class="column-left-body">
				<?php
					if(auth()->guard()->guest()==false)
					{
						echo "<button type=\"button\" class=\"btn btn-warning btn-block\" onclick=\"window.location.href='http://localhost:8000/project/add/{{$category}}'\" >++ADD++</button><hr>";
					}
					echo App\Http\Controllers\database_project_controller::display_catelog();
				?>
			</div>
			<div class="column-center-body">
			<form class="col-md-12" action="/project/<?php echo e($category); ?>/<?php echo e($key); ?>/edit_comple" method="POST">
				<table width="100%" cellpadding="10" style="background-image: url('http://localhost/laravel/blog/resources/views/image/bg_table.png')" >
				<?php echo e(csrf_field()); ?>

					<tr>
						<td width="20%" align="right"><b>productCode:</b></td>
						<td width="80%" align="left"><b><?php echo e($key); ?></b><?php echo e($error['productCode']); ?></td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>productName:</b></td>
						<td width="80%" align="left"><input name="productName" type="text" size="40" value="<?php echo e($old['productName']); ?>" ><?php echo e($error['productName']); ?></td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>productLine:</b></td>
						<td width="80%" align="left"><input name="productLine" type="text" value="<?php echo e($old['productLine']); ?>" ><?php echo e($error['productLine']); ?></td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>productScale:</b></td>
						<td width="80%" align="left"><input name="productScale" type="text" value="<?php echo e($old['productScale']); ?>" ><?php echo e($error['productScale']); ?></td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>productVendor:</b></td>
						<td width="80%" align="left"><input name="productVendor" type="text" value="<?php echo e($old['productVendor']); ?>" ><?php echo e($error['productVendor']); ?></td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>productDescription:</b></td>
						<td width="80%" align="left"><textarea name="productDescription" rows="4" cols="50"><?php echo e($old['productDescription']); ?></textarea><?php echo e($error['productDescription']); ?></td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>quantityInStock:</b></td>
						<td width="80%" align="left"><input name="quantityInStock" type="text" value="<?php echo e($old['quantityInStock']); ?>" ><?php echo e($error['quantityInStock']); ?></td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>buyPrice:</b></td>
						<td width="80%" align="left"><input name="buyPrice" type="text" value="<?php echo e($old['buyPrice']); ?>" ><?php echo e($error['buyPrice']); ?></td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>MSRP:</b></td>
						<td width="80%" align="left"><input name="MSRP" type="text" value="<?php echo e($old['MSRP']); ?>" ><?php echo e($error['MSRP']); ?></td>
					</tr>
					<tr>
						<td width="20%" align="right"><button type="reset" class="btn btn-secondary">Clear</button></td>
						<td width="80%" align="left"><button type="submit" class="btn btn-success">Submit</button></td>
					</tr>
					</form> 
				</table>
			</div>
		</div>
    </body>
</html>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\blog\resources\views/edit_product.blade.php ENDPATH**/ ?>