<html>
    <head>
        <title><?php echo $data['productName'] ?></title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="http://localhost/laravel/blog/resources/views/css/main.css"> <!--import css file-->
    </head>
    <body class="bg-image">
        <div class="row" style="margin:0px">
            <div class="column-left"><img src="http://localhost/laravel/blog/resources/views/image/logo.png" class="login-logo-image"></div>
            <div class="column-center"><h1>Company name</h1></div>
            <div class="column-right">
			<?php if(auth()->guard()->guest()): ?>
			<?php else: ?>
                <b>Employee code:</b><?php echo e(Auth::user()->employeeNumber); ?><br>
                <b>Employee name:</b><?php echo Auth::user()->employees['firstName'],Auth::user()->employees['lastName'] ?><br>
                <b>Department:</b><?php echo e(Auth::user()->employees['jobTitle']); ?>

			<?php endif; ?>
            </div>
        </div>
        <ul class="ul-menu-bar">
		<?php if(auth()->guard()->guest()): ?>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/products">products</a></li>
			<li class="li-menu-bar" style="float:right"><a href="<?php echo e(route('login')); ?>">Login</a></li>
		<?php else: ?>
			<li class="li-menu-bar"><a href="http://localhost:8000/project/products">products</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/orders">orders</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/customers">customers</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/employees">employees</a></li>
			<li class="li-menu-bar"><a href="http://localhost:8000/project/payments">payments</a></li>
			<?php 
				if(Auth::user()->employees['jobTitle'] == "VP Marketing")
				{
					echo "<li class=\"li-menu-bar\"><a href=\"http://localhost:8000/project/promotion\">promotion</a></li>";
				}
			?>
            <li class="li-menu-bar" style="float:right"><a class="active" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">logout</a></li>
        	<?php if(Auth::user()->employees['jobTitle'] == "President"){ ?>
			<li class="li-menu-bar" style="float:right"><a href="<?php echo e(route('register')); ?>">Register</a></li>
			<?php } ?>
		<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
		<?php endif; ?>
		</ul>
		<div class="row" style="margin:0px">
			<div class="column-left-body">
				<?php
					if(auth()->guard()->guest()==false)
					{
						echo "<button type=\"button\" class=\"btn btn-warning btn-block\" onclick=\"window.location.href='http://localhost:8000/project/add/".$category."'\" >++ADD++</button>";
						echo "<button type=\"button\" class=\"btn btn-info btn-block\"  onclick=\"window.location.href='http://localhost:8000/project/edit/".$category."/".$data['productCode']."'\">==EDIT==</button><hr>";
					}
					echo App\Http\Controllers\database_project_controller::display_catelog();
				?>
			</div>
			<div class="column-center-body">
				<table class="document">
                <tr>
                    <td align="center" style="padding: 10px"><h3>Name:<?php echo $data['productName'] ?></h3></td>
                </tr>
                <tr>
                    <td align="center" style="padding: 10px" rowspan="6"><img onerror="this.src='http://localhost/laravel/blog/resources/views/image/default_image.png'" src="http://localhost/laravel/blog/resources/views/image/product.jpg" ></td>
                    <td><h5>Code:<?php echo $data['productCode'] ?></h5></td>
                </tr>
                <tr>
                    <td><h5>Buyprice:<?php echo $data['buyPrice'] ?></h5></td>
                </tr>
                <tr>
                    <td><h5>MSRP:<?php echo $data['MSRP'] ?></h5></td>
                </tr>
				<tr>
                    <td><h5>is_preorder:<?php echo $data['is_preorder'] ?></h5></td>
                </tr>
                <tr>
                    <td><h5>scale:<?php echo $data['productScale'] ?></h5></td>
                </tr>
                <tr>
                    <td><h5>Quantity:<?php echo $data['quantityInStock'] ?></h5></td>
                </tr>
                <tr>
                    <td colspan="2" style="padding: 30px"><h3>Description:</h3><p><?php echo $data['productDescription'] ?></p></td>
                </tr>
                <tr>
                    <td colspan="2" style="padding: 30px"><h3>Initail Description:</h3><p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. 
                        Optio aspernatur dignissimos eum quasi accusantium fuga sapiente nesciunt iure. 
                        Quis eaque minus nostrum explicabo neque veritatis? Voluptatem soluta maiores deserunt iure?</p></td>
                </tr>
                <tr>
                    <td colspan="2" style="padding: 30px"><h3>Vender:</h3><?php echo $data['productVendor'] ?></td>
                </tr>
        </table>
			</div>
		</div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\laravel\blog\resources\views/product_detail.blade.php ENDPATH**/ ?>