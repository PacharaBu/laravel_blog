<?php if(auth()->guard()->guest()): ?>
<?php
	header('Location: http://localhost:8000/login');
	exit;
?>
<?php else: ?>
<html>
    <head>
        <title>New_Product</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="http://localhost/laravel/blog/resources/views/css/main.css"> <!--import css file-->
    </head>
	
    <body class="bg-image">
        <div class="row">
            <div class="column-left"><img src="http://localhost/laravel/blog/resources/views/image/logo.png" class="login-logo-image"></div>
            <div class="column-center"><h1>Company name</h1></div>
            <div class="column-right">
			<?php if(auth()->guard()->guest()): ?>
			<?php else: ?>
                <b>Employee code:</b><?php echo e(Auth::user()->employeeNumber); ?><br>
                <b>Employee name:</b><?php echo Auth::user()->employees['firstName'],Auth::user()->employees['lastName'] ?><br>
                <b>Department:</b><?php echo e(Auth::user()->employees['jobTitle']); ?>

			<?php endif; ?>
            </div>
        </div>
        <ul class="ul-menu-bar">
		<?php if(auth()->guard()->guest()): ?>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/products">products</a></li>
			<li class="li-menu-bar" style="float:right"><a href="<?php echo e(route('login')); ?>">Login</a></li>
			<li class="li-menu-bar" style="float:right"><a href="<?php echo e(route('register')); ?>">Register</a></li>
		<?php else: ?>
			<li class="li-menu-bar"><a href="http://localhost:8000/project/products">products</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/orders">orders</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/customers">customers</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/employees">employees</a></li>
            <li class="li-menu-bar" style="float:right"><a class="active" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">logout</a></li>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
		<?php endif; ?>
        </ul>
		<div class="row" style="margin:0px">
			<div class="column-left-body">
				<?php
					if(auth()->guard()->guest()==false)
					{
						echo "<button type=\"button\" class=\"btn btn-warning btn-block\" onclick=\"window.location.href='http://localhost:8000/project/add/".$category."'\" >++ADD++</button><hr>";
					}
					echo App\Http\Controllers\database_project_controller::display_catelog();
				?>
			</div>
			<div class="column-center-body">
			<form class="col-md-12" action="/project/<?php echo e($category); ?>/add_comple" method="POST">
				<table width="100%" cellpadding="10" style="background-image: url('http://localhost/laravel/blog/resources/views/image/bg_table.png')">
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="category" value="<?php echo e($category); ?>">
					<tr>
						<td width="20%" align="right"><b>orderNumber:</b></td>
						<td width="80%" align="left"><?php echo $key;?></td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>requiredDate:</b></td>
						<td width="80%" align="left"><input type="date" name="requiredDate"
															value="<?php echo e(old('requiredDate')); ?>">
							<?php if ($errors->has('requiredDate')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('requiredDate'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>shippedDate:</b></td>
						<td width="80%" align="left"><input type="date" name="shippedDate"
															value="<?php echo e(old('shippedDate')); ?>">
							<?php if ($errors->has('shippedDate')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('shippedDate'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>comments:</b></td>
						<td width="80%" align="left"><input name="comments" type="text" value="<?php echo e(old('comments')); ?>" >
							<?php if ($errors->has('comments')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('comments'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>customerNumber:</b></td>
						<td width="80%" align="left"><input name="customerNumber" type="text" value="<?php echo e(old('customerNumber')); ?>" >
							<?php if ($errors->has('customerNumber')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customerNumber'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<input name="key" type="hidden" value="<?php echo $key;?>">
						<td width="20%" align="right"></td>
						<td width="80%" align="left"><button type="submit" class="btn btn-success">Submit</button></td>
					</tr>
					<tr>
						<td colspan="2" align="center">
							<b>Select product</b>
						</td>
					</tr>
					<tr>
						<td colspan="2" align="center">
							<table border="1" width="100%">
							<tr>
								<th>productCode</th>
								<th>productName</th>
								<th>quantityOrdered</th>
								<th>priceEach</th>
							</tr>
							<?php 
								$total_price = 0;
							?>
							<?php foreach($select_product as $p){  ?>
								<tr>
										<td><?php echo $p['productCode']; ?></td>
										<td><?php echo $p['productName']; ?></td>
										<td><?php echo $p['quantityOrdered']; ?></td>
										<td><?php echo $p['priceEach']; ?></td>
								</tr>
							<?php
									$total_price = $total_price+doubleval($p['quantityOrdered'])*doubleval($p['priceEach']);
								} 
							?>
							<tr>
								<td colspan="3" align="right"><td> Total = <?php echo $total_price;?></td></td>
							</tr>
							</table>
						</td>
					</tr>
					</form> 
				</table>
			</div>
		</div>
    </body>
</html>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\blog\resources\views/add_order.blade.php ENDPATH**/ ?>