<?php
	if(auth()->guard()->guest() or Auth::user()->employees['jobTitle'] != "President")
	{
		header('Location: http://localhost:8000/project/products');
		exit;
	}
?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('employeeNumber')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="employeeNumber" value="<?php echo e(old('employeeNumber')); ?>" required autocomplete="employeeNumber" autofocus>

                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

						<hr>
						
						<div class="form-group row">
                            <label for="FirstsName" class="col-md-4 col-form-label text-md-right"><?php echo e(__('FirstsName')); ?></label>

                            <div class="col-md-6">
                                <input id="FirstsName" type="text" class="form-control <?php if ($errors->has('FirstsName')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('FirstsName'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="FirstsName" value="<?php echo e(old('FirstsName')); ?>" required autocomplete="FirstsName">

                                <?php if ($errors->has('FirstsName')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('FirstsName'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
						
						<div class="form-group row">
                            <label for="LastName" class="col-md-4 col-form-label text-md-right"><?php echo e(__('LastName')); ?></label>

                            <div class="col-md-6">
                                <input id="LastName" type="text" class="form-control <?php if ($errors->has('LastName')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('LastName'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="LastName" value="<?php echo e(old('LastName')); ?>" required autocomplete="LastName">

                                <?php if ($errors->has('LastName')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('LastName'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
						
						<div class="form-group row">
                            <label for="Extension" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Extension')); ?></label>

                            <div class="col-md-6">
                                <input id="Extension" type="text" class="form-control <?php if ($errors->has('Extension')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Extension'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="Extension" value="<?php echo e(old('Extension')); ?>" required autocomplete="Extension">

                                <?php if ($errors->has('Extension')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Extension'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
						
						<div class="form-group row">
                            <label for="Email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Email')); ?></label>

                            <div class="col-md-6">
                                <input id="Email" type="text" class="form-control <?php if ($errors->has('Email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="Email" value="<?php echo e(old('Email')); ?>" required autocomplete="Email">

                                <?php if ($errors->has('Email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
						
						<div class="form-group row">
                            <label for="officeCode" class="col-md-4 col-form-label text-md-right"><?php echo e(__('officeCode')); ?></label>

                            <div class="col-md-6">
                                <input id="officeCode" type="text" class="form-control <?php if ($errors->has('officeCode')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('officeCode'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="officeCode" value="<?php echo e(old('officeCode')); ?>" required autocomplete="officeCode">

                                <?php if ($errors->has('officeCode')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('officeCode'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
						
						<div class="form-group row">
                            <label for="reportsTo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('reportsTo')); ?></label>

                            <div class="col-md-6">
                                <input id="reportsTo" type="text" class="form-control <?php if ($errors->has('reportsTo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('reportsTo'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="reportsTo" value="<?php echo e(old('reportsTo')); ?>" required autocomplete="reportsTo">

                                <?php if ($errors->has('reportsTo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('reportsTo'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
						
						<div class="form-group row">
                            <label for="jobTitle" class="col-md-4 col-form-label text-md-right"><?php echo e(__('jobTitle')); ?></label>

                            <div class="col-md-6">
                                <input id="jobTitle" type="text" class="form-control <?php if ($errors->has('jobTitle')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jobTitle'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="jobTitle" value="<?php echo e(old('jobTitle')); ?>" required autocomplete="jobTitle">

                                <?php if ($errors->has('jobTitle')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jobTitle'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
						
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\blog\resources\views/auth/register.blade.php ENDPATH**/ ?>