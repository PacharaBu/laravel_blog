<?php if(auth()->guard()->guest()): ?>
<?php
	header('Location: http://localhost:8000/login');
	exit;
?>
<?php else: ?>
<html>
    <head>
        <title>New_Product</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="http://localhost/laravel/blog/resources/views/css/main.css"> <!--import css file-->
    </head>
    <body class="bg-image">
        <div class="row">
            <div class="column-left"><img src="http://localhost/laravel/blog/resources/views/image/logo.png" class="login-logo-image"></div>
            <div class="column-center"><h1>Company name</h1></div>
            <div class="column-right">
			<?php if(auth()->guard()->guest()): ?>
			<?php else: ?>
                <b>Employee code:</b><?php echo e(Auth::user()->employeeNumber); ?><br>
                <b>Employee name:</b><?php echo Auth::user()->employees['firstName'],Auth::user()->employees['lastName'] ?><br>
                <b>Department:</b><?php echo e(Auth::user()->employees['jobTitle']); ?>

			<?php endif; ?>
            </div>
        </div>
        <ul class="ul-menu-bar">
		<?php if(auth()->guard()->guest()): ?>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/products">products</a></li>
			<li class="li-menu-bar" style="float:right"><a href="<?php echo e(route('login')); ?>">Login</a></li>
			<li class="li-menu-bar" style="float:right"><a href="<?php echo e(route('register')); ?>">Register</a></li>
		<?php else: ?>
			<li class="li-menu-bar"><a href="http://localhost:8000/project/products">products</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/orders">orders</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/customers">customers</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/employees">employees</a></li>
			<li class="li-menu-bar"><a href="http://localhost:8000/project/payments">payments</a></li>
			<?php 
				if(Auth::user()->employees['jobTitle'] == "VP Marketing")
				{
					echo "<li class=\"li-menu-bar\"><a href=\"http://localhost:8000/project/promotion\">promotion</a></li>";
				}
			?>
            <li class="li-menu-bar" style="float:right"><a class="active" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">logout</a></li>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
		<?php endif; ?>
        </ul>
		<div class="row" style="margin:0px">
			<div class="column-left-body">
				<?php
					if(auth()->guard()->guest()==false)
					{
						echo "<button type=\"button\" class=\"btn btn-warning btn-block\" onclick=\"window.location.href='http://localhost:8000/project/add/".$category."'\" >++ADD++</button><hr>";
					}
					echo App\Http\Controllers\database_project_controller::display_catelog();
				?>
			</div>
			<div class="column-center-body">
			<form class="col-md-12" action="/project/<?php echo e($category); ?>/add_comple" method="POST">
				<table width="100%" cellpadding="10" style="background-image: url('http://localhost/laravel/blog/resources/views/image/bg_table.png')" >
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="category" value="<?php echo e($category); ?>">
					<tr>
						<td width="20%" align="right"><b>productCode:</b></td>
						<td width="80%" align="left"><input name="productCode" type="text" value="<?php echo e(old('productCode')); ?>" >
							<?php if ($errors->has('productCode')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('productCode'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>productName:</b></td>
						<td width="80%" align="left"><input name="productName" type="text" size="40" value="<?php echo e(old('productName')); ?>" >
							<?php if ($errors->has('productName')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('productName'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>productLine:</b></td>
						<td width="80%" align="left"><input name="productLine" type="text" value="<?php echo e(old('productLine')); ?>" >
							<?php if ($errors->has('productLine')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('productLine'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>productScale:</b></td>
						<td width="80%" align="left"><input name="productScale" type="text" value="<?php echo e(old('productScale')); ?>" >
							<?php if ($errors->has('productScale')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('productScale'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>productVendor:</b></td>
						<td width="80%" align="left"><input name="productVendor" type="text" value="<?php echo e(old('productVendor')); ?>" >
							<?php if ($errors->has('productVendor')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('productVendor'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>productDescription:</b></td>
						<td width="80%" align="left"><textarea name="productDescription" rows="4" cols="50"><?php echo e(old('productDescription')); ?></textarea>
							<?php if ($errors->has('productDescription')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('productDescription'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>quantityInStock:</b></td>
						<td width="80%" align="left"><input id="quantityInStock" name="quantityInStock" type="text" value="<?php echo e(old('quantityInStock')); ?>" >
							<?php if ($errors->has('quantityInStock')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('quantityInStock'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>Perorder:</b></td>
						<td width="80%" align="left"><input type="checkbox" id="is_preorder" name="is_preorder" value="T" onclick="lock_qty()"> Preorder</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>buyPrice:</b></td>
						<td width="80%" align="left"><input name="buyPrice" type="text" value="<?php echo e(old('buyPrice')); ?>" >
							<?php if ($errors->has('buyPrice')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('buyPrice'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>						
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>MSRP:</b></td>
						<td width="80%" align="left"><input name="MSRP" type="text" value="<?php echo e(old('MSRP')); ?>" >
							<?php if ($errors->has('MSRP')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('MSRP'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>	
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><button type="reset" class="btn btn-secondary">Clear</button></td>
						<td width="80%" align="left"><button type="submit" class="btn btn-success">Submit</button></td>
					</tr>
					</form> 
				</table>
			</div>
		</div>
		
		<script>
			function lock_qty() 
			{
			var checkBox = document.getElementById("is_preorder");
			var text = document.getElementById("quantityInStock");
			if (checkBox.checked == true){
				text.disabled = true;
				text.value = 0;
			} else {
					text.disabled = false;
					text.value = "";
				}
			}
		</script>
		
    </body>
</html>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\blog\resources\views/add_product.blade.php ENDPATH**/ ?>