<?php if(auth()->guard()->guest()): ?>
<?php
	header('Location: http://localhost:8000/login');
	exit;
?>
<?php else: ?>
<html>
    <head>
        <title><?php echo $data_or['orderNumber'] ?></title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="http://localhost/laravel/blog/resources/views/css/main.css"> <!--import css file-->
    </head>
    <body class="bg-image">
        <div class="row" style="margin:0px">
            <div class="column-left"><img src="http://localhost/laravel/blog/resources/views/image/logo.png" class="login-logo-image"></div>
            <div class="column-center"><h1>Company name</h1></div>
            <div class="column-right">
			<?php if(auth()->guard()->guest()): ?>
			<?php else: ?>
                <b>Employee code:</b><?php echo e(Auth::user()->employeeNumber); ?><br>
                <b>Employee name:</b><?php echo Auth::user()->employees['firstName'],Auth::user()->employees['lastName'] ?><br>
                <b>Department:</b><?php echo e(Auth::user()->employees['jobTitle']); ?>

			<?php endif; ?>
            </div>
        </div>
        <ul class="ul-menu-bar">
		<?php if(auth()->guard()->guest()): ?>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/products">products</a></li>
			<li class="li-menu-bar" style="float:right"><a href="<?php echo e(route('login')); ?>">Login</a></li>
		<?php else: ?>
			<li class="li-menu-bar"><a href="http://localhost:8000/project/products">products</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/orders">orders</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/customers">customers</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/employees">employees</a></li>
            <li class="li-menu-bar" style="float:right"><a class="active" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">logout</a></li>
        	<?php if(Auth::user()->employees['jobTitle'] == "President"){ ?>
			<li class="li-menu-bar" style="float:right"><a href="<?php echo e(route('register')); ?>">Register</a></li>
			<?php } ?>
		<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
		<?php endif; ?>
		</ul>
		<div class="row" style="margin:0px">
			<div class="column-left-body">
				<?php
					if(auth()->guard()->guest()==false)
					{
						echo "<button type=\"button\" class=\"btn btn-info btn-block\" onclick=\"window.location.href='http://localhost:8000/project/edit/".$category."/".$data_or['orderNumber']."'\">==EDIT==</button><hr>";
					}
					echo App\Http\Controllers\database_project_controller::display_catelog();
				?>
			</div>
			<div class="column-center-body">
				<table class="document" cellpadding="10">
			<tr>
				<td width="50%" align="right"><b>Order Number:</b></td>
				<td width="50%" align="left"><?php echo $data_or['orderNumber'] ?></td>
			</tr>
			<tr>
				<td width="50%" align="right"><b>Customer Number:</b></td>
				<td width="50%" align="left"><?php echo $data_or['customerNumber'] ?></td>
			</tr>
			<tr>
				<td width="50%" align="right"><b>Customer Name:</b></td>
				<td width="50%" align="left"><?php echo $data_cu['customerName'] ?></td>
			</tr>
			<tr>
				<td width="50%" align="right"><b>Order Date:</b></td>
				<td width="50%" align="left"><?php echo $data_or['orderDate'] ?></td>
			</tr>
			<tr>
				<td width="50%" align="right"><b>Required Date:</b></td>
				<td width="50%" align="left"><?php echo $data_or['requiredDate'] ?></td>
			</tr>			
			<tr>
				<td width="50%" align="right"><b>comments:</b></td>
				<td width="50%" align="left"><?php echo $data_or['comments'] ?></td>
			</tr>
			<tr>
				<td width="50%" align="right"><b>status:</b></td>
				<td width="50%" align="left"><?php echo $data_or['status'] ?></td>
			</tr>
			<tr>
				<td width="50%" align="right"><b>Check Number:</b></td>
				<td width="50%" align="left">????</td>
			</tr>
			<tr>
				<td width="50%" align="right"><b>Shipped Date:</b></td>
				<td width="50%" align="left"><?php echo $data_or['shippedDate'] ?></td>
			</tr>
			<tr>
				<td width="50%" align="right"><b>Amount:</b></td>
				<td width="50%" align="left">????</td>
			</tr>
			<tr>
				<td colspan="2">
					<table class="table table-dark">
						<tr>
							<?php  
								echo "<th>productCode</th>";
								echo "<th>productName</th>";
								echo "<th>orderLineNumber</th>";
								echo "<th>quantityOrdered</th>";
								echo "<th>priceEach</th>";
								echo "<th>promotion</th>";
							?>
						</tr>
							<?php
								$total_price = 0;
								foreach($data_or_de as $index => $row_or_de)
								{
									echo "<tr>";
									echo "<td>$row_or_de[productCode]</td>";
									echo "<td>$data_pr[$index]</td>";
									echo "<td>$row_or_de[orderLineNumber]</td>";
									echo "<td>$row_or_de[quantityOrdered]</td>";
									echo "<td>$row_or_de[priceEach]</td>";
									if(App\Http\Controllers\database_project_controller::ck_promotion($row_or_de['productCode']) and $row_or_de['quantityOrdered']>=2)
										{
											echo "<td>T</td>";
											$total_price = $total_price+doubleval($row_or_de['quantityOrdered']-1)*doubleval($row_or_de['priceEach']);
										}
									else
										{
											echo "<td>F</td>";
											$total_price = $total_price+doubleval($row_or_de['quantityOrdered'])*doubleval($row_or_de['priceEach']);
										}
									echo "</tr>";
								}
								echo "<tr>";
								echo "<td colspan=\"5\" align=\"right\">Total Price: $total_price</td>";
								echo "</tr>";
							?>
					</table>
				</td>
			</tr>
        </table>
			</div>
		</div>
    </body>
</html>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\blog\resources\views/order_detail.blade.php ENDPATH**/ ?>