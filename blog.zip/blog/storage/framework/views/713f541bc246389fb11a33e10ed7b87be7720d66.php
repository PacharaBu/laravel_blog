<?php if(auth()->guard()->guest()): ?>
<?php
	header('Location: http://localhost:8000/login');
	exit;
?>
<?php else: ?>
<html>
    <head>
        <title>New_Product</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="http://localhost/laravel/blog/resources/views/css/main.css"> <!--import css file-->
    </head>
	
    <body class="bg-image">
        <div class="row">
            <div class="column-left"><img src="http://localhost/laravel/blog/resources/views/image/logo.png" class="login-logo-image"></div>
            <div class="column-center"><h1>Company name</h1></div>
            <div class="column-right">
			<?php if(auth()->guard()->guest()): ?>
			<?php else: ?>
                <b>Employee code:</b><?php echo e(Auth::user()->employeeNumber); ?><br>
                <b>Employee name:</b><?php echo Auth::user()->employees['firstName'],Auth::user()->employees['lastName'] ?><br>
                <b>Department:</b><?php echo e(Auth::user()->employees['jobTitle']); ?>

			<?php endif; ?>
            </div>
        </div>
        <ul class="ul-menu-bar">
		<?php if(auth()->guard()->guest()): ?>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/products">products</a></li>
			<li class="li-menu-bar" style="float:right"><a href="<?php echo e(route('login')); ?>">Login</a></li>
			<li class="li-menu-bar" style="float:right"><a href="<?php echo e(route('register')); ?>">Register</a></li>
		<?php else: ?>
			<li class="li-menu-bar"><a href="http://localhost:8000/project/products">products</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/orders">orders</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/customers">customers</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/employees">employees</a></li>
			<li class="li-menu-bar"><a href="http://localhost:8000/project/payments">payments</a></li>
			<?php 
				if(Auth::user()->employees['jobTitle'] == "VP Marketing")
				{
					echo "<li class=\"li-menu-bar\"><a href=\"http://localhost:8000/project/promotion\">promotion</a></li>";
				}
			?>
            <li class="li-menu-bar" style="float:right"><a class="active" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">logout</a></li>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
		<?php endif; ?>
        </ul>
		<div class="row" style="margin:0px">
			<div class="column-left-body">
				<?php
					if(auth()->guard()->guest()==false)
					{
						echo "<button type=\"button\" class=\"btn btn-warning btn-block\" onclick=\"window.location.href='http://localhost:8000/project/add/cart'\" >++ADD++</button><hr>";
					}
					echo App\Http\Controllers\database_project_controller::display_catelog();
				?>
			</div>
			<div class="column-center-body">
				<table width="100%" cellpadding="10" style="background-image: url('http://localhost/laravel/blog/resources/views/image/bg_table.png')">
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="category" value="<?php echo e($category); ?>">
					<tr>
						<td width="20%" align="right"><b>orderNumber:</b></td>
						<td width="80%" align="left"><?php echo $key;?></td>
						<td><button type="button" class="btn btn-light" onclick="window.location.href='http://localhost:8000/project/add/orders/<?php echo e($key); ?>'" >Next</button></td>
					</tr>
					<tr>
						<td colspan="2" align="center">
							<b>Select product</b>
						</td>
					</tr>
					<tr>
						<td colspan="2" align="center">
							<table border="1" width="100%">
							<tr>
								<th>productCode</th>
								<th>productName</th>
								<th>quantityOrdered</th>
								<th>priceEach</th>
								<th>Promotion</th>
								<th>Delete</th>
							</tr>
							<?php 
								$total_price = 0;
							?>
							<?php foreach($select_product as $p){  ?>
								<tr>
									<form class="col-md-12" action="/project/delete_form_cart/" method="POST">
									<?php echo csrf_field(); ?> 
										<input name="key" type="hidden" value="<?php echo $key;?>">
										<input name="productCode" type="hidden" value="<?php echo $p['productCode'];?>">
										<td><?php echo $p['productCode']; ?></td>
										<td><?php echo $p['productName']; ?></td>
										<td><?php echo $p['quantityOrdered']; ?></td>
										<td><?php echo $p['priceEach']; ?></td>
										<?php
											if(App\Http\Controllers\database_project_controller::ck_promotion($p['productCode']) and $p['quantityOrdered']>=2)
											{
												echo "<td>T</td>";
												$total_price = $total_price+doubleval($p['quantityOrdered']-1)*doubleval($p['priceEach']);
											}
											else
											{
												echo "<td>F</td>";
												$total_price = $total_price+doubleval($p['quantityOrdered'])*doubleval($p['priceEach']);
											}
										?>
										<td><button type="submit">X</button></td>
									</form>
								</tr>
							<?php
								} 
							?>
							<tr>
								<td colspan="3" align="right"><td> Total = <?php echo $total_price;?></td></td>
							</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td colspan="2" align="center">
							<b>All product</b>
						</td>
					</tr>
					<tr>
						<td colspan="2" align="center">
							<table border="1" width="100%">
							<tr>
								<th>productCode</th>
								<th>productName</th>
								<th>quantityInStock</th>
								<th>MSRP</th>
								<th>Promotion</th>
								<th>quantity</th>
								<th>ADD</th>
							</tr>
							<?php foreach($product as $p){  ?>
								<tr>
										<td><?php echo $p['productCode']; ?></td>
										<td><?php echo $p['productName']; ?></td>
										<td><?php echo $p['quantityInStock']; ?></td>
										<td><?php echo $p['MSRP']; ?></td>
										<?php
											if(App\Http\Controllers\database_project_controller::ck_promotion($p['productCode']))
											{
												echo "<td>T</td>";
											}
											else
											{
												echo "<td>F</td>";
											}
										?>	
									<form class="col-md-12" action="/project/add_to_cart/" method="POST">
									<?php echo csrf_field(); ?> 
										<input name="productCode" type="hidden" value="<?php echo $p['productCode'];?>">
										<input name="productName" type="hidden" value="<?php echo $p['productName'];?>">
										<input name="MSRP" type="hidden" value="<?php echo $p['MSRP'];?>">
										<input name="key" type="hidden" value="<?php echo $key;?>">
										<td><input name="quantity" type="text" value="<?php echo e(old('quantity')); ?>" ></td>
										<td><button type="submit" >+</button></td>
									</form>
								</tr>
							<?php } ?>
							</table>
						</td>
					</tr>
				</table>
			</div>
		</div>
    </body>
</html>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\blog\resources\views/add_product_to_cart.blade.php ENDPATH**/ ?>