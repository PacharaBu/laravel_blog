<?php if(auth()->guard()->guest()): ?>
<?php
	header('Location: http://localhost:8000/login');
	exit;
?>
<?php else: ?>
<html>
    <head>
        <title>New_Customer</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="http://localhost/laravel/blog/resources/views/css/main.css"> <!--import css file-->
    </head>
    <body class="bg-image">
        <div class="row">
            <div class="column-left"><img src="http://localhost/laravel/blog/resources/views/image/logo.png" class="login-logo-image"></div>
            <div class="column-center"><h1>Company name</h1></div>
            <div class="column-right">
			<?php if(auth()->guard()->guest()): ?>
			<?php else: ?>
                <b>Employee code:</b><?php echo e(Auth::user()->employeeNumber); ?><br>
                <b>Employee name:</b><?php echo Auth::user()->employees['firstName'],Auth::user()->employees['lastName'] ?><br>
                <b>Department:</b><?php echo e(Auth::user()->employees['jobTitle']); ?>

			<?php endif; ?>
            </div>
        </div>
        <ul class="ul-menu-bar">
		<?php if(auth()->guard()->guest()): ?>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/products">products</a></li>
			<li class="li-menu-bar" style="float:right"><a href="<?php echo e(route('login')); ?>">Login</a></li>
			<li class="li-menu-bar" style="float:right"><a href="<?php echo e(route('register')); ?>">Register</a></li>
		<?php else: ?>
			<li class="li-menu-bar"><a href="http://localhost:8000/project/products">products</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/orders">orders</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/customers">customers</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/employees">employees</a></li>
            <li class="li-menu-bar" style="float:right"><a class="active" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">logout</a></li>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
		<?php endif; ?>
        </ul>
		<div class="row" style="margin:0px">
			<div class="column-left-body">
				<?php
					if(auth()->guard()->guest()==false)
					{
						echo "<button type=\"button\" class=\"btn btn-warning btn-block\" onclick=\"window.location.href='http://localhost:8000/project/add/".$category."'\" >++ADD++</button><hr>";
					}
					echo App\Http\Controllers\database_project_controller::display_catelog();
				?>
			</div>
			<div class="column-center-body">
			<form class="col-md-12" action="/project/<?php echo e($category); ?>/<?php echo e($key); ?>/edit_comple" method="POST">
				<table width="100%" cellpadding="10" style="background-image: url('http://localhost/laravel/blog/resources/views/image/bg_table.png')" >
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="category" value="<?php echo e($category); ?>">
					<tr>
						<td width="20%" align="right"><b>customerNumber:</b></td>
						<td width="80%" align="left"><b><?php echo e($key); ?></b>
							<?php if ($errors->has('key')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('key'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>customerName:</b></td>
						<td width="80%" align="left"><input name="customerName" type="text" size="40" value="<?php echo e($old['customerName']); ?>" >
							<?php if ($errors->has('customerName')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customerName'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>contactLastName:</b></td>
						<td width="80%" align="left"><input name="contactLastName" type="text" value="<?php echo e($old['contactLastName']); ?>" >
							<?php if ($errors->has('contactLastName')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contactLastName'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>contactFirstName:</b></td>
						<td width="80%" align="left"><input name="contactFirstName" type="text" value="<?php echo e($old['contactFirstName']); ?>" >
							<?php if ($errors->has('contactFirstName')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contactFirstName'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>phone:</b></td>
						<td width="80%" align="left"><input name="phone" type="text" value="<?php echo e($old['phone']); ?>" >
							<?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>addressLine1:</b></td>
						<td width="80%" align="left"><input name="addressLine1" type="text" value="<?php echo e($old['addressLine1']); ?>" >
							<?php if ($errors->has('addressLine1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('addressLine1'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>addressLine2:</b></td>
						<td width="80%" align="left"><input name="addressLine2" type="text" value="<?php echo e($old['addressLine2']); ?>" >
							<?php if ($errors->has('addressLine2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('addressLine2'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>city:</b></td>
						<td width="80%" align="left"><input name="city" type="text" value="<?php echo e($old['city']); ?>" >
							<?php if ($errors->has('city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>						
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>state:</b></td>
						<td width="80%" align="left"><input name="state" type="text" value="<?php echo e($old['state']); ?>" >
							<?php if ($errors->has('state')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('state'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>	
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>postalCode:</b></td>
						<td width="80%" align="left"><input name="postalCode" type="text" value="<?php echo e($old['postalCode']); ?>" >
							<?php if ($errors->has('postalCode')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('postalCode'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>	
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>country:</b></td>
						<td width="80%" align="left"><input name="country" type="text" value="<?php echo e($old['country']); ?>" >
							<?php if ($errors->has('country')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('country'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>	
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>salesRepEmployeeNumber:</b></td>
						<td width="80%" align="left"><input name="salesRepEmployeeNumber" type="text" value="<?php echo e($old['salesRepEmployeeNumber']); ?>" >
							<?php if ($errors->has('salesRepEmployeeNumber')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('salesRepEmployeeNumber'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>	
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><b>creditLimit:</b></td>
						<td width="80%" align="left"><input name="creditLimit" type="text" value="<?php echo e($old['creditLimit']); ?>" >
							<?php if ($errors->has('creditLimit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('creditLimit'); ?>
							<?php echo e($message); ?>

							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>	
						</td>
					</tr>
					<tr>
						<td width="20%" align="right"><button type="reset" class="btn btn-secondary">Clear</button></td>
						<td width="80%" align="left"><button type="submit" class="btn btn-success">Submit</button></td>
					</tr>
					</form> 
				</table>
			</div>
		</div>
    </body>
</html>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\blog\resources\views/edit_customer.blade.php ENDPATH**/ ?>