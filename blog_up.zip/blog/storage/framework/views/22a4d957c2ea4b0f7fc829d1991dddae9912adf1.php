<?php
	if(auth()->guard()->guest())
	{
		if($category!="products")
		{
			header('Location: http://localhost:8000/login');
			exit;
		}
	}
?>
<html>
    <head>
        <title>main</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="http://localhost/laravel/blog/resources/views/css/main.css"> <!--import css file-->
    </head>
    <body class="bg-image">
        <div class="row" style="margin:0px">
            <div class="column-left"><img src="http://localhost/laravel/blog/resources/views/image/logo.png" class="login-logo-image"></div>
            <div class="column-center"><h1>Company name</h1></div>
            <div class="column-right">
			<?php if(auth()->guard()->guest()): ?>
			<?php else: ?>
                <b>Employee code:</b><?php echo e(Auth::user()->employeeNumber); ?><br>
                <b>Employee name:</b><?php echo Auth::user()->employees['firstName'],Auth::user()->employees['lastName'] ?><br>
                <b>Department:</b><?php echo e(Auth::user()->employees['jobTitle']); ?>

			<?php endif; ?>
            </div>
        </div>
        <ul class="ul-menu-bar">
		<?php if(auth()->guard()->guest()): ?>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/products">products</a></li>
			<li class="li-menu-bar" style="float:right"><a href="<?php echo e(route('login')); ?>">Login</a></li>
			<li class="li-menu-bar" style="float:right"><a href="<?php echo e(route('register')); ?>">Register</a></li>
		<?php else: ?>
			<li class="li-menu-bar"><a href="http://localhost:8000/project/products">products</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/orders">orders</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/customers">customers</a></li>
            <li class="li-menu-bar"><a href="http://localhost:8000/project/employees">employees</a></li>
            <li class="li-menu-bar" style="float:right"><a class="active" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">logout</a></li>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
		<?php endif; ?>
		</ul>
		<div class="row" style="margin:0px">
			<div class="column-left-body">
				<?php
					if(auth()->guard()->guest()==false)
					{
						echo "<button type=\"button\" class=\"btn btn-warning btn-block\" onclick=\"window.location.href='http://localhost:8000/project/add/".$category."'\" >++ADD++</button><hr>";
					}
					echo App\Http\Controllers\database_project_controller::display_catelog();
				?>
			</div>
			<div class="column-center-body">
				<table class="table table-hover" style="background-image: url('http://localhost/laravel/blog/resources/views/image/bg_table.png')">
            <tr>
				<?php  
					foreach($colum as $c)
					{
							echo "<th>";
							echo $c;
							echo "</th>";
                    }
					if(auth()->guard()->guest()==false)
					{
						echo "<th>Delete</th>";
					}
				?>
            </tr>
				<?php
					foreach($data as $row)
					{
						echo "<tr>";
						foreach($colum as $c)
						{
							if($category=="products")
							{
								echo "<td  onclick=\"window.location='http://localhost:8000/project/products/$row[productCode]'\" > $row[$c] </td>";
							}
							else if($category=="employees")
							{
								echo "<td  onclick=\"window.location='http://localhost:8000/project/employees/$row[employeeNumber]'\" > $row[$c] </td>";
							}
							else
							{
								echo "<td> $row[$c] </td>";
							}
						}
						if(auth()->guard()->guest()==false)
						{
							echo "<td><button type=\"button\" class=\"btn btn-danger\" onclick=\"window.location.href='http://localhost:8000/project/delete/$category/$row[productCode]'\" >X</button></td>";
						}
						echo "</tr>";
					}
				?>
        </table>
		<div class="container">
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo e($d->name); ?>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>

		<?php echo e($data->links()); ?>

			</div>
		</div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\laravel\blog\resources\views/main.blade.php ENDPATH**/ ?>