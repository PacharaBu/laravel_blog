<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\products;
use App\employees;
use App\customers;
use App\orders;
use App\productlines;

class database_project_controller extends Controller
{
	public function login_ck()
	{
		//return view("login");
		if(auth()->guard()->guest())
		{
			header('Location: http://localhost:8000/login');
			exit;
		}
	}
	
	public function login()
	{
		//return view("login");
	}
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
		if($id=="products")
		{
			$colum = ["productCode","productName","buyPrice","quantityInStock","productVendor"];
			$data = products::paginate(25);
		}
		else if($id=="orders")
		{
			$colum = ["orderNumber","customerNumber","orderDate","comments","status"];
			$data = orders::paginate(20);
		}
		else if($id=="customers")
		{
			$colum = ["customerNumber","customerName","phone","salesRepEmployeeNumber","creditLimit"];
			$data = customers::paginate(25);
		}
		else if($id=="employees")
		{
			$colum = ["employeeNumber","firstName","lastName","officeCode","jobTitle"];
			$data = employees::paginate(25);
		}
		else
		{
			abort(404);
		}
        return view("main",["data"=>$data,"colum"=>$colum,"category"=>$id]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
	
	public function add($category)
	{
		$old['productCode'] = "";
		$old['productName'] = "";
		$old['productLine'] = "";
		$old['productScale'] = "";
		$old['productVendor'] = "";
		$old['productDescription'] = "";
		$old['quantityInStock'] = "";
		$old['buyPrice'] = "";
		$old['MSRP'] = "";
		
		$error['productCode'] = "";
		$error['productName'] = "";
		$error['productLine'] = "";
		$error['productScale'] = "";
		$error['productVendor'] = "";
		$error['productDescription'] = "";
		$error['quantityInStock'] = "";
		$error['buyPrice'] = "";
		$error['MSRP'] = "";
		return view('add_product',["error"=>$error,"category"=>$category,"old"=>$old]);
	}
	
	public function edit_data($category,$key)
	{
		$pk = products::where('productCode', '=', $key)->first();
		if($pk==null)
		{
			abort(404);
		}
		
		$old = products::where('productCode', '=', $key)->first();
		
		$error['productCode'] = "";
		$error['productName'] = "";
		$error['productLine'] = "";
		$error['productScale'] = "";
		$error['productVendor'] = "";
		$error['productDescription'] = "";
		$error['quantityInStock'] = "";
		$error['buyPrice'] = "";
		$error['MSRP'] = "";
		
		return view("edit_product",["error"=>$error,"category"=>$category,"key"=>$key,"old"=>$old]);
	}

	public function edit_comple(Request $request,$category,$key)
	{
		$this->login_ck();
		
		$error['productCode'] = "";	
		$error['productName'] = "";
		$error['productLine'] = "";
		$error['productScale'] = "";
		$error['productVendor'] = "";
		$error['productDescription'] = "";
		$error['quantityInStock'] = "";
		$error['buyPrice'] = "";
		$error['MSRP'] = "";
		
		$pk = products::where('productCode', '=', $key)->first();
		$fk = productlines::where('productLine', '=', $request->input('productLine'))->first();
		
		if($pk==null || $key == null)
		{
			$error['productCode'] = "*";
		}
		if($fk==null || $request->input('productLine') == null)
		{
			$error['productLine'] = "*";
		}
		if($request->input('productName') == null)
		{
			$error['productName'] = "*";
		}
		if($request->input('productScale') == null)
		{
			$error['productScale'] = "*";
		}
		if($request->input('productVendor') == null)
		{
			$error['productVendor'] = "*";
		}
		if($request->input('productDescription') == null)
		{
			$error['productDescription'] = "*";
		}
		if($request->input('quantityInStock') == null)
		{
			$error['quantityInStock'] = "*";
		}
		if($request->input('buyPrice') == null)
		{
			$error['buyPrice'] = "*";
		}
		if($request->input('MSRP') == null)
		{
			$error['MSRP'] = "*";
		}
		
		$old = products::where('productCode', '=', $key)->first();
		foreach( $error as $e)
		{ 
			if($e=="*")
			{
				return view("edit_product",["error"=>$error,"category"=>$category,"key"=>$key,"old"=>$request]);
			}
		} 
		
		products::where('productCode',$key)->update([
			 'productName' => $request->input('productName'),
			 'productLine' => $request->input('productLine'),
			 'productScale' => $request->input('productScale'),
			 'productVendor' => $request->input('productVendor'),
			 'productDescription' => $request->input('productDescription'),
			 'quantityInStock' => $request->input('quantityInStock'),
			 'buyPrice' => $request->input('buyPrice'),
			 'MSRP' => $request->input('MSRP')
			 ]);
			 
		$data = products::where('productCode', '=', $key)->first();
		return view("product_detail",["data"=>$data,"category"=>"products"]);
		
	}
	
	public function delete_data($category,$key)
	{
		$this->login_ck();
		
		products::where('productCode',$key)->delete();
		return $this->show($category);
	}
	
	public function add_comple(Request $request,$category)
	{
		$this->login_ck();
		
		$error['productCode'] = "";
		$error['productName'] = "";
		$error['productLine'] = "";
		$error['productScale'] = "";
		$error['productVendor'] = "";
		$error['productDescription'] = "";
		$error['quantityInStock'] = "";
		$error['buyPrice'] = "";
		$error['MSRP'] = "";
		
		$pk = products::where('productCode', '=', $request->input('productCode'))->first();
		$fk = productlines::where('productLine', '=', $request->input('productLine'))->first();
		
		if($pk!=null || $request->input('productCode') == null)
		{
			$error['productCode'] = "*";
		}
		if($fk==null || $request->input('productLine') == null)
		{
			$error['productLine'] = "*";
		}
		if($request->input('productName') == null)
		{
			$error['productName'] = "*";
		}
		if($request->input('productScale') == null)
		{
			$error['productScale'] = "*";
		}
		if($request->input('productVendor') == null)
		{
			$error['productVendor'] = "*";
		}
		if($request->input('productDescription') == null)
		{
			$error['productDescription'] = "*";
		}
		if($request->input('quantityInStock') == null)
		{
			$error['quantityInStock'] = "*";
		}
		if($request->input('buyPrice') == null)
		{
			$error['buyPrice'] = "*";
		}
		if($request->input('MSRP') == null)
		{
			$error['MSRP'] = "*";
		}
		
		foreach( $error as $e)
		{ 
			if($e=="*")
			{
				return view('add_product',["error"=>$error,"category"=>$category,"old"=>$request]);
			}
		} 
		
		products::create([
			 'productCode' => $request->input('productCode'),
			 'productName' => $request->input('productName'),
			 'productLine' => $request->input('productLine'),
			 'productScale' => $request->input('productScale'),
			 'productVendor' => $request->input('productVendor'),
			 'productDescription' => $request->input('productDescription'),
			 'quantityInStock' => $request->input('quantityInStock'),
			 'buyPrice' => $request->input('buyPrice'),
			 'MSRP' => $request->input('MSRP')
			 ]);
			 
			 $data = products::where('productCode', '=', $request->input('productCode'))->first();
			 return view("product_detail",["data"=>$data,"category"=>"products"]);
		
	}
	
	public function products_fillter($colum,$fillter)
    {
		if($colum == "productVendor")
		{
			$colum = ["productCode","productName","buyPrice","quantityInStock","productVendor"];
			$data = products::where('productVendor', '=', $fillter)->paginate(25);
		}
		else if($colum == "productScale")
		{
			$colum = ["productCode","productName","buyPrice","quantityInStock","productVendor"];
			$data = products::where('productScale', '=', $fillter)->paginate(25);
		}
        return view("main",["data"=>$data,"colum"=>$colum,"category"=>"products"]);
    }
	
	public function products_details($productCode)
	{
		$data = products::where('productCode', '=', $productCode)->first();
		return view("product_detail",["data"=>$data,"category"=>"products"]);
	}
	
	public function employees_details($employeeNumber)
	{
		$data_em = employees::where("employeeNumber",'=',$employeeNumber)->first();
		$data_off = employees::where("employeeNumber",'=',$employeeNumber)->first()->offices; 
		return view("employees_detail",["data_em"=>$data_em,"data_off"=>$data_off,"category"=>"employees"]);
	}
	
	public static function display_catelog()
	{	
		echo 	"<ul class=\"ul-menu-list\">
				<li class=\"li-menu-list\"><a class=\"main-catelog\" href=\"#home\">Catelog</a></li>
				<li class=\"li-menu-list\"><a class=\"sub-catelog\" href=\"#news\">Product Vendor</a></li>";

		$result = products::distinct()->get("productVendor");
		foreach($result as $data)
		{
			echo "<li class='li-menu-list'><a href='http://localhost:8000/project/products/fillter/productVendor/".$data['productVendor']."'>".$data['productVendor']."</a></li>";
		}
		
		echo "<li class=\"li-menu-list\"><a class=\"sub-catelog\" href=\"#news\">Product Scale</a></li>";

		$result =  products::distinct()->get("productScale");
		foreach($result as $data)
		{
			echo "<li class='li-menu-list'><a href='http://localhost:8000/project/products/fillter/productScale/".$data['productScale']."'>".$data['productScale']."</a></li>";
		}
				
		echo "</ul>";
	}	
}